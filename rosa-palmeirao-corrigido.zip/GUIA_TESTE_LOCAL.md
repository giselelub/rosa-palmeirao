# 🧪 Guia de Teste Local - Rosa Palmeirão

Este documento fornece instruções passo a passo para testar o aplicativo Rosa Palmeirão em seu ambiente local.

---

## 📋 Pré-requisitos

Antes de começar, certifique-se de ter instalado:

- **Node.js** (versão 18+) - [Download](https://nodejs.org/)
- **npm** ou **pnpm** (gerenciador de pacotes)
- **Git** (para clonar o repositório)
- **SQLite** ou **MySQL** (para banco de dados)

### Verificar Instalação

```bash
node --version    # Deve mostrar v18+
npm --version     # Deve mostrar 9+
git --version     # Deve mostrar 2.x+
```

---

## 🚀 Configuração Inicial

### 1. Clonar o Repositório

```bash
git clone <seu-repositorio-url>
cd rosa-palmeirao
```

### 2. Instalar Dependências

```bash
# Usando npm
npm install

# Ou usando pnpm (mais rápido)
pnpm install
```

### 3. Configurar Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto:

```env
# Database
DATABASE_URL="sqlite:./app.db"
# Ou para MySQL:
# DATABASE_URL="mysql://usuario:senha@localhost:3306/rosa_palmeirao"

# API Keys (opcional para testes)
OPENAI_API_KEY="sua-chave-aqui"

# App Config
VITE_APP_TITLE="Rosa Palmeirão"
VITE_APP_LOGO="https://via.placeholder.com/200"

# Server
SERVER_PORT=5000
```

### 4. Criar Banco de Dados

```bash
# Para SQLite (automático)
npm run db:push

# Ou para MySQL, primeiro crie o banco:
# mysql -u root -p
# CREATE DATABASE rosa_palmeirao;
# exit
```

### 5. Iniciar o Servidor de Desenvolvimento

```bash
# Terminal 1 - Backend
npm run dev

# Terminal 2 - Frontend (em outro terminal)
npm run dev:client
```

O aplicativo estará disponível em: **http://localhost:5173**

---

## 🧪 Testando Cada Funcionalidade

### ✅ Teste 1: Cadastro e Login

**Objetivo:** Verificar se o sistema de autenticação funciona

**Passos:**

1. Abra http://localhost:5173
2. Clique em "Cadastre-se"
3. Preencha os dados:
   - Nome: `Rosa Teste`
   - Email: `rosa@teste.com`
   - Senha: `Teste123`
   - Confirmar Senha: `Teste123`
4. Clique em "Cadastrar"
5. Você deve ser redirecionado para a página de login
6. Faça login com os dados cadastrados
7. Você deve ser redirecionado para o Dashboard

**Resultado Esperado:**
- ✅ Cadastro bem-sucedido
- ✅ Login bem-sucedido
- ✅ Acesso ao Dashboard

**Possíveis Erros:**
- "Email já existe" - Use um email diferente
- "Senha fraca" - Use uma senha com números e letras
- "Erro de conexão" - Verifique se o servidor está rodando

---

### ✅ Teste 2: Criar Personagem

**Objetivo:** Verificar se o formulário de criação de personagem funciona

**Passos:**

1. No Dashboard, clique em "Criar Novo Personagem"
2. **Passo 1 - Informações Básicas:**
   - Nome: `Luna`
   - Categoria: `🌶️ Spicy`
   - Clique em "Próximo"

3. **Passo 2 - Atributos Físicos:**
   - Etnia: `Latina`
   - Cor do Cabelo: `Preto azulado`
   - Estilo de Cabelo: `Longo e ondulado`
   - Cor dos Olhos: `Verdes esmeralda`
   - Formato do Rosto: `Coração`
   - Tipo de Corpo: `Curvilíneo`
   - Clique em "Próximo"

4. **Passo 3 - Estilo e Aparência:**
   - Vestimenta: `Vestido de seda preta`
   - Acessórios: Digite `Colar de diamantes` e clique "Adicionar"
   - Cenário: `Varanda de hotel 5 estrelas em Dubai`
   - Clique em "Próximo"

5. **Passo 4 - Personalidade:**
   - Arquétipo: `Femme Fatale`
   - Tom de Voz: `Misterioso e provocante`
   - Interesses: Digite `Arte contemporânea` e clique "Adicionar"
   - Clique em "Próximo"

6. **Passo 5 - Pré-visualização:**
   - Revise os dados
   - Clique em "Salvar Personagem"

**Resultado Esperado:**
- ✅ Todos os 5 passos completados
- ✅ Personagem salvo com sucesso
- ✅ Redirecionado para Dashboard
- ✅ Personagem aparece na lista

**Possíveis Erros:**
- "Nome é obrigatório" - Preencha o campo de nome
- "Erro ao salvar" - Verifique se o servidor está rodando

---

### ✅ Teste 3: Gerar Imagem

**Objetivo:** Verificar se a geração de imagens funciona

**Passos:**

1. No Dashboard, encontre o personagem criado
2. Clique no ícone de câmera (📷) ou em "Gerar Imagem"
3. Na página de geração:
   - Tipo de Conteúdo: Selecione `🌶️ Spicy`
   - Tamanho: Selecione `Grande (1024x1024)`
   - Clique em "Gerar Imagem"
4. Aguarde a geração (pode levar alguns segundos)
5. Quando a imagem aparecer:
   - Clique em "Baixar" para fazer download
   - Clique em "Compartilhar" para copiar o link

**Resultado Esperado:**
- ✅ Imagem gerada com sucesso
- ✅ Imagem exibida na tela
- ✅ Botão de download funciona
- ✅ Botão de compartilhamento copia o link

**Possíveis Erros:**
- "Erro ao gerar imagem" - Verifique se a API está configurada
- Imagem não aparece - Verifique o console do navegador (F12)

---

### ✅ Teste 4: Gerar Vídeo de Dança

**Objetivo:** Verificar se a geração de vídeos funciona

**Passos:**

1. No Dashboard, clique no ícone de vídeo (🎬) do personagem
2. Na página de geração:
   - Nome da Música: Digite `Blinding Lights - The Weeknd`
   - Tipo de Conteúdo: Selecione `🌶️ Spicy`
   - Qualidade: Selecione `Full HD (1080x1920)`
   - Clique em "Gerar Vídeo"
3. Aguarde a geração (pode levar alguns segundos)
4. Quando o vídeo aparecer:
   - Clique em "Baixar" para fazer download
   - Clique em "Compartilhar" para copiar o link

**Resultado Esperado:**
- ✅ Vídeo gerado com sucesso
- ✅ Vídeo exibido com player
- ✅ Botão de download funciona
- ✅ Botão de compartilhamento copia o link

**Possíveis Erros:**
- "Erro ao gerar vídeo" - Verifique se a API está configurada
- Vídeo não aparece - Verifique o console do navegador (F12)

---

### ✅ Teste 5: Conversação Normal

**Objetivo:** Verificar se a conversação normal funciona

**Passos:**

1. No Dashboard, clique no ícone de chat (💬) do personagem
2. Na página de chat:
   - Tipo: Selecione `💬 Conversação Normal`
   - Clique em uma das mensagens rápidas, por exemplo: "Oi, tudo bem?"
3. Aguarde a resposta do personagem
4. Digite uma mensagem personalizada: "Qual é seu maior sonho?"
5. Clique no botão de envio ou pressione Enter
6. Aguarde a resposta
7. Clique em "Baixar Conversa" para salvar em TXT

**Resultado Esperado:**
- ✅ Mensagens aparecem no chat
- ✅ Respostas do personagem aparecem
- ✅ Histórico é mantido
- ✅ Download de conversa funciona

**Possíveis Erros:**
- "Erro ao gerar resposta" - Verifique se a API está configurada
- Chat não aparece - Verifique o console do navegador (F12)

---

### ✅ Teste 6: Conversação Picante

**Objetivo:** Verificar se a conversação picante funciona

**Passos:**

1. No Dashboard, clique no ícone de chat (💬) do personagem
2. Na página de chat:
   - Tipo: Selecione `🌶️ Conversação Picante`
   - Clique em uma das mensagens rápidas: "Você é muito atraente"
3. Aguarde a resposta do personagem
4. Continue a conversa com mensagens picantes
5. Clique em "Baixar Conversa" para salvar

**Resultado Esperado:**
- ✅ Conversação picante funciona
- ✅ Respostas são apropriadas
- ✅ Download funciona

**Possíveis Erros:**
- Respostas genéricas - Isso é esperado na versão de teste
- Chat não aparece - Verifique o console do navegador (F12)

---

### ✅ Teste 7: Gerar Criativos para Anúncios

**Objetivo:** Verificar se o gerador de criativos funciona

**Passos:**

1. No Dashboard, clique em "Gerar Criativos"
2. Na página de criativos:
   - Plataforma: Selecione `📘 Facebook`
   - Tamanho: Selecione `1080x1080`
   - Nome do Produto: Digite `Camiseta Premium`
   - URL da Imagem: Deixe em branco
   - Clique em "Gerar 1 Criativo"
3. Aguarde a geração
4. Quando o criativo aparecer:
   - Clique em "Copiar Headline"
   - Clique em "Copiar Descrição"
   - Clique em "Baixar Criativo"

5. Repita para outras plataformas:
   - TikTok
   - Instagram
   - Kwai

6. Teste "Gerar 5 Criativos" para gerar múltiplas opções

**Resultado Esperado:**
- ✅ Criativos gerados com sucesso
- ✅ Headlines persuasivos
- ✅ Descrições atrativas
- ✅ Botões de copiar funcionam
- ✅ Download funciona

**Possíveis Erros:**
- "Erro ao gerar criativo" - Verifique se a API está configurada
- Headlines genéricos - Isso é esperado na versão de teste

---

### ✅ Teste 8: Galeria de Gerações

**Objetivo:** Verificar se a galeria funciona

**Passos:**

1. No Dashboard, clique em "Galeria de Gerações"
2. Você deve ver todos os conteúdos gerados anteriormente
3. Teste os filtros:
   - Clique em "Imagens" - Deve mostrar apenas imagens
   - Clique em "Vídeos" - Deve mostrar apenas vídeos
   - Clique em "Chats" - Deve mostrar apenas chats
   - Clique em "Todos" - Deve mostrar tudo
4. Para cada item:
   - Clique em "Baixar" (ícone de seta)
   - Clique em "Compartilhar" (ícone de compartilhamento)
   - Clique em "Deletar" (ícone de lixo)

**Resultado Esperado:**
- ✅ Galeria mostra todos os itens
- ✅ Filtros funcionam corretamente
- ✅ Download funciona
- ✅ Compartilhamento funciona
- ✅ Deleção funciona

**Possíveis Erros:**
- Galeria vazia - Você precisa gerar conteúdo primeiro
- Filtros não funcionam - Verifique o console do navegador (F12)

---

### ✅ Teste 9: Logout

**Objetivo:** Verificar se o logout funciona

**Passos:**

1. No Dashboard, procure pelo menu de usuário (geralmente no canto superior direito)
2. Clique em "Logout"
3. Você deve ser redirecionado para a página inicial
4. Tente acessar http://localhost:5173/dashboard
5. Você deve ser redirecionado para a página de login

**Resultado Esperado:**
- ✅ Logout bem-sucedido
- ✅ Redirecionamento para página inicial
- ✅ Não consegue acessar dashboard sem login

**Possíveis Erros:**
- Botão de logout não aparece - Verifique o header do dashboard
- Ainda consegue acessar dashboard - Verifique se o logout foi executado

---

## 🐛 Testando Validações

### Teste de Validação de Cadastro

**Cenário 1: Email inválido**
- Email: `email-invalido`
- Resultado esperado: Erro "Email inválido"

**Cenário 2: Senha fraca**
- Senha: `123` (sem letras)
- Resultado esperado: Erro "Senha deve conter letras"

**Cenário 3: Senhas não correspondem**
- Senha: `Teste123`
- Confirmar: `Teste456`
- Resultado esperado: Erro "Senhas não correspondem"

**Cenário 4: Email já existe**
- Email: `rosa@teste.com` (já cadastrado)
- Resultado esperado: Erro "Email já existe"

---

## 📊 Checklist de Testes

Marque cada teste conforme você o completar:

```
Autenticação
- [ ] Cadastro bem-sucedido
- [ ] Login bem-sucedido
- [ ] Logout bem-sucedido
- [ ] Validações de cadastro funcionam

Personagem
- [ ] Criar personagem com sucesso
- [ ] Todos os 5 passos funcionam
- [ ] Pré-visualização mostra dados corretos
- [ ] Personagem aparece no dashboard

Geração de Conteúdo
- [ ] Gerar imagem (Glamour)
- [ ] Gerar imagem (Spicy)
- [ ] Gerar imagem (Adult +18)
- [ ] Gerar vídeo (Glamour)
- [ ] Gerar vídeo (Spicy)
- [ ] Gerar vídeo (Adult +18)
- [ ] Conversação Normal funciona
- [ ] Conversação Picante funciona

Downloads
- [ ] Download de imagem funciona
- [ ] Download de vídeo funciona
- [ ] Download de chat funciona
- [ ] Download de criativo funciona

Criativos
- [ ] Gerar criativo Facebook
- [ ] Gerar criativo TikTok
- [ ] Gerar criativo Instagram
- [ ] Gerar criativo Kwai
- [ ] Copiar headline funciona
- [ ] Copiar descrição funciona
- [ ] Gerar 5 criativos funciona

Galeria
- [ ] Galeria mostra todos os itens
- [ ] Filtro de imagens funciona
- [ ] Filtro de vídeos funciona
- [ ] Filtro de chats funciona
- [ ] Download da galeria funciona
- [ ] Compartilhamento funciona
- [ ] Deleção funciona

Interface
- [ ] Design responsivo (desktop)
- [ ] Design responsivo (tablet)
- [ ] Tema escuro funciona
- [ ] Tema claro funciona
- [ ] Todos os botões são clicáveis
- [ ] Mensagens de erro aparecem
```

---

## 🔍 Ferramentas de Debug

### Abrir Console do Navegador

Pressione **F12** ou **Ctrl+Shift+I** (Windows/Linux) / **Cmd+Option+I** (Mac)

### Verificar Erros

1. Abra a aba "Console"
2. Procure por mensagens de erro em vermelho
3. Clique na mensagem para ver mais detalhes

### Verificar Requisições de Rede

1. Abra a aba "Network"
2. Realize uma ação (ex: gerar imagem)
3. Procure por requisições que falharam (status 4xx ou 5xx)

### Verificar Armazenamento Local

1. Abra a aba "Application"
2. Procure por "Local Storage" e "Cookies"
3. Verifique se os dados estão sendo salvos

---

## 🚨 Troubleshooting

### Problema: "Cannot GET /"

**Solução:**
```bash
# Verifique se o servidor está rodando
npm run dev

# Verifique a porta
# Deve estar em http://localhost:5173
```

### Problema: "Database connection error"

**Solução:**
```bash
# Verifique a variável DATABASE_URL
cat .env.local

# Recrie o banco de dados
npm run db:push

# Ou para MySQL:
mysql -u root -p rosa_palmeirao < schema.sql
```

### Problema: "Module not found"

**Solução:**
```bash
# Reinstale as dependências
rm -rf node_modules
npm install

# Ou com pnpm
pnpm install
```

### Problema: "CORS error"

**Solução:**
```bash
# Verifique se o backend está rodando em http://localhost:5000
# Verifique se o frontend está em http://localhost:5173

# Reinicie ambos os servidores
npm run dev
```

### Problema: "Imagem/Vídeo não gera"

**Solução:**
```bash
# Verifique se a API está configurada
cat .env.local | grep OPENAI_API_KEY

# Se não estiver, adicione a chave:
# OPENAI_API_KEY="sua-chave-aqui"

# Reinicie o servidor
npm run dev
```

---

## 📝 Relatório de Teste

Após completar todos os testes, crie um relatório:

```markdown
# Relatório de Teste - Rosa Palmeirão

**Data:** [Data]
**Testador:** [Seu Nome]
**Versão:** 1.0.0

## Resumo
- Total de testes: 50
- Testes passados: X
- Testes falhados: Y
- Taxa de sucesso: Z%

## Testes Falhados
1. [Descrição do erro]
2. [Descrição do erro]

## Observações
- [Observação 1]
- [Observação 2]

## Recomendações
- [Recomendação 1]
- [Recomendação 2]
```

---

## ✅ Conclusão

Se todos os testes passarem, seu aplicativo está pronto para:
1. ✅ Deployment em produção
2. ✅ Testes com usuários reais
3. ✅ Integração com APIs reais

**Próximos passos:**
- Integrar APIs de geração de imagens (Hugging Face, Replicate)
- Integrar APIs de geração de vídeos (Runway, Pika)
- Fazer deploy em Vercel ou Railway
- Coletar feedback dos usuários

---

**Boa sorte com os testes! 🚀**

