# 🎬 Rosa Palmeirão - Gerador de Influencers Digitais

Um aplicativo web moderno para criar, personalizar e gerenciar influencers digitais com IA. Gere imagens, vídeos e tenha conversas com seus personagens criados.

---

## ✨ Funcionalidades

- 🎨 **Criação de Personagens:** Customize influencers digitais com atributos físicos e de personalidade
- 🖼️ **Geração de Imagens:** Crie imagens de alta qualidade usando IA (Stable Diffusion)
- 🎬 **Geração de Vídeos:** Produza vídeos de dança e animação
- 💬 **Chat com IA:** Converse com seus personagens usando OpenAI
- 💳 **Sistema de Assinaturas:** Implemente planos pagos (PayPal/Stripe)
- 👥 **Gerenciamento de Usuários:** Autenticação segura e perfis de usuário
- 📊 **Dashboard:** Visualize todas as criações e estatísticas

---

## 🛠️ Stack Tecnológico

### Frontend
- **React 18** - UI interativa
- **Vite** - Build tool rápido
- **TypeScript** - Type safety
- **Tailwind CSS** - Estilização
- **React Hook Form** - Gerenciamento de formulários
- **Wouter** - Roteamento leve

### Backend
- **Node.js/Express** - Servidor web
- **TypeScript** - Type safety
- **tRPC** - API type-safe
- **Drizzle ORM** - Gerenciamento de banco de dados

### Banco de Dados
- **PostgreSQL** (Neon) - Banco de dados relacional

### Serviços Externos
- **Hugging Face** - Geração de imagens
- **OpenAI** - Chat e processamento de IA
- **Cloudinary** - Storage de imagens
- **Resend** - Email
- **PayPal** - Pagamentos

---

## 🚀 Começar Rápido

### Desenvolvimento Local

1. **Clone o repositório:**
   ```bash
   git clone https://github.com/seu-usuario/rosa-palmeirao.git
   cd rosa-palmeirao
   ```

2. **Instale as dependências:**
   ```bash
   npm install
   ```

3. **Configure as variáveis de ambiente:**
   ```bash
   cp .env.example .env
   # Edite o .env com suas chaves de API
   ```

4. **Execute o desenvolvimento:**
   ```bash
   npm run dev
   ```

   - Frontend: http://localhost:5173
   - Backend: http://localhost:5000

5. **Crie as tabelas do banco de dados:**
   ```bash
   npm run db:push
   ```

---

## 📦 Deploy

### Deploy Gratuito Completo

Para um guia completo de deploy gratuito usando:
- **Neon** (PostgreSQL)
- **Render** (Backend)
- **Vercel** (Frontend)

Veja: **[GUIA_COMPLETO_LANCAMENTO_GRATUITO.md](./GUIA_COMPLETO_LANCAMENTO_GRATUITO.md)**

### Deploy Rápido

Para um resumo rápido dos passos essenciais:

Veja: **[DEPLOY_RAPIDO.md](./DEPLOY_RAPIDO.md)**

---

## 🔑 Variáveis de Ambiente Necessárias

```bash
# Banco de Dados
DATABASE_URL=postgresql://user:password@host:5432/database

# Hugging Face (Geração de Imagens)
HUGGING_FACE_API_KEY=hf_xxxxxxxxxxxxx
HUGGING_FACE_MODEL=stabilityai/stable-diffusion-2

# OpenAI (Chat)
OPENAI_API_KEY=sk-xxxxxxxxxxxxx

# Cloudinary (Storage)
CLOUDINARY_CLOUD_NAME=xxxxx
CLOUDINARY_API_KEY=xxxxx
CLOUDINARY_API_SECRET=xxxxx

# Resend (Email)
RESEND_API_KEY=re_xxxxxxxxxxxxx

# PayPal (Pagamentos)
PAYPAL_CLIENT_ID=xxxxx
PAYPAL_CLIENT_SECRET=xxxxx
PAYPAL_MODE=sandbox

# Configuração da Aplicação
VITE_APP_TITLE=Rosa Palmeirão
VITE_API_URL=http://localhost:5000
SERVER_PORT=5000
NODE_ENV=development
SESSION_SECRET=sua-chave-secreta-aqui
```

---

## 📁 Estrutura do Projeto

```
rosa-palmeirao/
├── src/
│   ├── components/          # Componentes React
│   ├── pages/              # Páginas da aplicação
│   ├── server.ts           # Servidor Express
│   ├── routers.ts          # Rotas tRPC
│   ├── db.ts               # Funções de banco de dados
│   └── main.tsx            # Entrada do React
├── schema.ts               # Schema do Drizzle ORM
├── drizzle.config.ts       # Configuração do Drizzle
├── package.json            # Dependências
├── vite.config.ts          # Configuração do Vite
├── vercel.json             # Configuração do Vercel
├── render.yaml             # Configuração do Render
├── .env                    # Variáveis de ambiente
└── README.md               # Este arquivo
```

---

## 🧪 Scripts Disponíveis

```bash
# Desenvolvimento
npm run dev              # Inicia frontend e backend em paralelo
npm run dev:server      # Inicia apenas o servidor
npm run dev:client      # Inicia apenas o frontend

# Build
npm run build           # Build para produção
npm run preview         # Preview do build

# Banco de Dados
npm run db:push         # Sincroniza schema com banco
npm run db:generate     # Gera migrações
npm run db:migrate      # Executa migrações
npm run db:studio       # Abre Drizzle Studio

# Validação
npm run type-check      # Verifica tipos TypeScript
npm run lint            # Verifica código com ESLint

# Produção
npm start               # Inicia servidor de produção
```

---

## 💰 Implementar Assinaturas Pagas

O projeto já possui estrutura para assinaturas. Para implementar:

1. Configure suas credenciais do PayPal/Stripe
2. Implemente a lógica de cobrança nos routers
3. Atualize os limites de uso baseado no plano

---

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

---

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

---

## 📞 Suporte

Para suporte, abra uma issue no GitHub ou entre em contato através do email.

---

## 🙏 Agradecimentos

- Hugging Face pela API de geração de imagens
- OpenAI pelo ChatGPT
- Vercel, Render e Neon pelos serviços gratuitos
- Comunidade open-source

---

**Desenvolvido com ❤️ para criadores de conteúdo**

