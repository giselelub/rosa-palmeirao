import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Download, Trash2, Share2, MessageCircle, Music, Image as ImageIcon, Video } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

export default function ContentViewer() {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/generate/:characterId/:type");
  const [downloading, setDownloading] = useState(false);

  const characterId = params?.characterId ? parseInt(params.characterId) : null;
  const contentType = params?.type as "image" | "dance" | "chat" | undefined;

  // Buscar personagem
  const { data: character } = trpc.character.save.getById.useQuery(
    { id: characterId || 0 },
    { enabled: !!characterId }
  );

  // Gerar imagem
  const generateImageMutation = trpc.contentGeneration.generateImage.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        // Atualizar histórico
        refetchHistory();
      }
    },
  });

  // Gerar dança
  const generateDanceMutation = trpc.contentGeneration.generateDance.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        refetchHistory();
      }
    },
  });

  // Obter histórico
  const { data: history = [], refetch: refetchHistory } = trpc.contentGeneration.getHistory.useQuery();

  const handleGenerateImage = async () => {
    if (!characterId) return;
    await generateImageMutation.mutateAsync({
      characterId,
      contentType: character?.contentRating || "glamour",
    });
  };

  const handleGenerateDance = async () => {
    if (!characterId) return;
    const musicName = prompt("Digite o nome da música:");
    if (!musicName) return;

    await generateDanceMutation.mutateAsync({
      characterId,
      musicName,
      contentType: character?.contentRating || "glamour",
    });
  };

  const handleDownload = async (url: string, filename: string) => {
    setDownloading(true);
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert("Erro ao baixar arquivo");
    } finally {
      setDownloading(false);
    }
  };

  const handleShare = (url: string) => {
    if (navigator.share) {
      navigator.share({
        title: "Confira meu conteúdo gerado!",
        url: url,
      });
    } else {
      navigator.clipboard.writeText(url);
      alert("Link copiado para a área de transferência!");
    }
  };

  if (!characterId) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900 flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">Personagem não encontrado</p>
            <Link href="/dashboard">
              <Button className="w-full mt-4">Voltar ao Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
        </div>
      </header>

      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {character?.name || "Personagem"}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Gere imagens, vídeos e diálogos para seu personagem
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Generation Options */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Gerar Conteúdo</CardTitle>
                <CardDescription>
                  {character?.contentRating === "glamour" && "🌸 Glamour"}
                  {character?.contentRating === "spicy" && "🌶️ Spicy"}
                  {character?.contentRating === "adult" && "🔞 Adult"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                  onClick={handleGenerateImage}
                  disabled={generateImageMutation.isPending}
                >
                  <ImageIcon className="h-4 w-4 mr-2" />
                  {generateImageMutation.isPending ? "Gerando..." : "Gerar Imagem"}
                </Button>

                <Button
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                  onClick={handleGenerateDance}
                  disabled={generateDanceMutation.isPending}
                >
                  <Video className="h-4 w-4 mr-2" />
                  {generateDanceMutation.isPending ? "Gerando..." : "Gerar Dança"}
                </Button>

                <Button variant="outline" className="w-full">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Gerar Chat
                </Button>

                <Link href="/dashboard">
                  <Button variant="outline" className="w-full">
                    Voltar
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Content Display */}
          <div className="lg:col-span-2">
            {history.length > 0 ? (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Histórico de Gerações</h2>
                {history.map((item, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {item.type === "image" && <ImageIcon className="h-5 w-5 text-blue-500" />}
                          {item.type === "animation" && <Video className="h-5 w-5 text-purple-500" />}
                          {item.type === "chat" && <MessageCircle className="h-5 w-5 text-pink-500" />}
                          <CardTitle className="text-lg">
                            {item.type === "image" && "Imagem"}
                            {item.type === "animation" && "Vídeo de Dança"}
                            {item.type === "chat" && "Chat"}
                          </CardTitle>
                        </div>
                        <span className="text-xs text-gray-500">
                          {new Date(item.createdAt).toLocaleDateString("pt-BR")}
                        </span>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Image Preview */}
                      {item.type === "image" && item.resultUrl && (
                        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                          <img
                            src={item.resultUrl}
                            alt="Generated"
                            className="w-full h-auto"
                          />
                        </div>
                      )}

                      {/* Video Preview */}
                      {item.type === "animation" && item.resultUrl && (
                        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                          <video
                            src={item.resultUrl}
                            controls
                            className="w-full h-auto"
                          />
                        </div>
                      )}

                      {/* Chat Display */}
                      {item.type === "chat" && item.resultData && (
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                          <p className="text-sm">
                            <strong>Você:</strong> {item.prompt}
                          </p>
                          <p className="text-sm mt-2">
                            <strong>{character?.name}:</strong>{" "}
                            {JSON.parse(item.resultData).response}
                          </p>
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-2">
                        {(item.type === "image" || item.type === "animation") && item.resultUrl && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() =>
                                handleDownload(
                                  item.resultUrl!,
                                  `${item.type}_${Date.now()}.${item.type === "image" ? "png" : "mp4"}`
                                )
                              }
                              disabled={downloading}
                            >
                              <Download className="h-4 w-4 mr-1" />
                              Baixar
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleShare(item.resultUrl!)}
                            >
                              <Share2 className="h-4 w-4 mr-1" />
                              Compartilhar
                            </Button>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-12 pb-12 text-center">
                  <Sparkles className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Nenhum conteúdo gerado ainda. Clique em "Gerar Imagem" ou "Gerar Dança" para começar!
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

