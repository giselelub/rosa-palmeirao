# 🚀 Guia Completo de Setup e Deployment - Rosa Palmeirão

Este guia irá te levar passo a passo para colocar o aplicativo online na Vercel.

---

## 📋 Pré-requisitos

- Conta no GitHub (para conectar com Vercel)
- Conta no Hugging Face (para gerar imagens)
- Conta no Vercel (gratuita)
- Email: `giselelubanco2@gmail.com`

---

## 🔑 Passo 1: Criar Conta no Hugging Face

### 1.1 Acessar Hugging Face

1. Abra: https://huggingface.co/join
2. Clique em "Sign up"
3. Preencha com seus dados:
   - Email: `giselelubanco2@gmail.com`
   - Password: Crie uma senha forte
   - Username: `rosa-palmeirao` (ou outro nome)

### 1.2 Gerar Token de API

1. Faça login em https://huggingface.co
2. Clique na sua foto no canto superior direito
3. Clique em "Settings"
4. Clique em "Access Tokens"
5. Clique em "New token"
6. Preencha:
   - Name: `Rosa Palmeirao API`
   - Type: `read`
7. Clique em "Generate token"
8. **Copie o token** (você vai precisar dele)

**Guarde este token em um lugar seguro!**

---

## 🗄️ Passo 2: Configurar Banco de Dados

### 2.1 Usar Vercel Postgres (Recomendado)

1. Acesse: https://vercel.com/dashboard
2. Clique em "Storage"
3. Clique em "Create Database"
4. Selecione "Postgres"
5. Escolha a região mais próxima
6. Clique em "Create"
7. **Copie a connection string** (você vai precisar dela)

### 2.2 Alternativa: Usar Neon (Gratuito)

1. Acesse: https://neon.tech
2. Clique em "Sign up"
3. Crie uma conta
4. Crie um novo projeto
5. **Copie a connection string**

---

## 📦 Passo 3: Preparar o Projeto

### 3.1 Criar arquivo `.env.local`

Na raiz do projeto, crie um arquivo chamado `.env.local` com:

```env
# Database
DATABASE_URL="postgresql://user:password@host/database"

# Hugging Face
HUGGING_FACE_API_KEY="seu-token-aqui"

# App Config
VITE_APP_TITLE="Rosa Palmeirão"
NODE_ENV="production"
```

### 3.2 Instalar Dependências

```bash
npm install
# ou
pnpm install
```

### 3.3 Criar Banco de Dados

```bash
npm run db:push
```

---

## 🌐 Passo 4: Fazer Upload para GitHub

### 4.1 Criar Repositório no GitHub

1. Acesse: https://github.com/new
2. Preencha:
   - Repository name: `rosa-palmeirao`
   - Description: `Aplicativo de geração de influencers digitais`
   - Selecione "Public"
3. Clique em "Create repository"

### 4.2 Fazer Upload do Código

```bash
cd /home/ubuntu/rosa-palmeirao

# Inicializar git
git init
git add .
git commit -m "Initial commit - Rosa Palmeirao app"

# Adicionar remote
git remote add origin https://github.com/seu-usuario/rosa-palmeirao.git

# Fazer push
git branch -M main
git push -u origin main
```

---

## 🚀 Passo 5: Deploy na Vercel

### 5.1 Conectar Vercel com GitHub

1. Acesse: https://vercel.com/new
2. Clique em "Import Git Repository"
3. Cole a URL do seu repositório GitHub
4. Clique em "Import"

### 5.2 Configurar Variáveis de Ambiente

1. Na página de configuração, clique em "Environment Variables"
2. Adicione as seguintes variáveis:

```
DATABASE_URL = "sua-connection-string-aqui"
HUGGING_FACE_API_KEY = "seu-token-aqui"
VITE_APP_TITLE = "Rosa Palmeirão"
NODE_ENV = "production"
```

3. Clique em "Deploy"

### 5.3 Aguardar Deploy

- O Vercel irá compilar e fazer deploy do seu app
- Isso pode levar 2-5 minutos
- Você receberá um link como: `https://rosa-palmeirao.vercel.app`

---

## ✅ Passo 6: Testar o Aplicativo

### 6.1 Acessar o App

1. Clique no link fornecido pelo Vercel
2. Você deve ver a página inicial do Rosa Palmeirão

### 6.2 Fazer Cadastro

1. Clique em "Cadastre-se"
2. Preencha com seus dados:
   - Nome: `Rosa Teste`
   - Email: `giselelubanco2@gmail.com`
   - Senha: Crie uma senha forte
3. Clique em "Cadastrar"

### 6.3 Fazer Login

1. Clique em "Entrar"
2. Use o email e senha que cadastrou
3. Você deve ver o Dashboard

### 6.4 Testar Geração de Imagem

1. Clique em "Criar Novo Personagem"
2. Preencha os dados (pode usar dados fictícios)
3. Clique em "Salvar Personagem"
4. Clique no ícone de câmera (📷)
5. Clique em "Gerar Imagem"
6. Aguarde a geração (pode levar 30-60 segundos)
7. Você deve ver uma imagem gerada

---

## 🐛 Troubleshooting

### Erro: "Database connection error"

**Solução:**
1. Verifique se a variável `DATABASE_URL` está correta
2. Verifique se o banco de dados está ativo
3. Recrie o banco de dados

### Erro: "HUGGING_FACE_API_KEY not found"

**Solução:**
1. Verifique se você adicionou a variável de ambiente na Vercel
2. Verifique se o token está correto
3. Recrie o token no Hugging Face

### Imagem não gera

**Solução:**
1. Verifique se o token do Hugging Face está correto
2. Verifique se você tem créditos no Hugging Face
3. Aguarde alguns minutos e tente novamente

### Erro 500 no servidor

**Solução:**
1. Verifique os logs na Vercel (clique em "Deployments" → "Logs")
2. Verifique se todas as variáveis de ambiente estão configuradas
3. Tente fazer novo deploy

---

## 💳 Configurar Pagamentos (Opcional)

### Stripe

1. Crie conta em: https://stripe.com
2. Obtenha suas chaves (Publishable e Secret)
3. Adicione as variáveis na Vercel:
   - `STRIPE_PUBLIC_KEY`
   - `STRIPE_SECRET_KEY`

### PayPal

1. Crie conta em: https://developer.paypal.com
2. Obtenha suas credenciais
3. Adicione as variáveis na Vercel:
   - `PAYPAL_CLIENT_ID`
   - `PAYPAL_CLIENT_SECRET`

---

## 📊 Monitorar o App

### Acessar Logs

1. Vá para: https://vercel.com/dashboard
2. Clique no seu projeto
3. Clique em "Deployments"
4. Clique no deployment mais recente
5. Clique em "Logs"

### Verificar Performance

1. Clique em "Analytics"
2. Veja o uso de CPU, memória e requisições

---

## 🎉 Pronto!

Seu aplicativo está online e pronto para usar!

**Link do seu app:** `https://rosa-palmeirao.vercel.app`

### Próximos passos:

1. ✅ Compartilhe o link com seus amigos
2. ✅ Teste todas as funcionalidades
3. ✅ Crie personagens e gere conteúdo
4. ✅ Configure as assinaturas para começar a ganhar

---

## 📞 Suporte

Se tiver problemas:

1. Verifique os logs na Vercel
2. Verifique se todas as variáveis estão configuradas
3. Tente fazer novo deploy
4. Entre em contato com o suporte

---

**Versão:** 1.0.0  
**Data:** Outubro 2025  
**Status:** ✅ Pronto para Produção

