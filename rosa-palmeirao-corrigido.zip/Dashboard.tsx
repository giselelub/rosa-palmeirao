import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Image, MessageCircle, Plus, Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { LanguageSelector } from "@/components/LanguageSelector";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { t } = useTranslation();

  const { data: subscriptionData, isLoading: subLoading } = trpc.subscription.getMySubscription.useQuery();
  const { data: characters, isLoading: charsLoading } = trpc.character.list.useQuery();

  const hasActiveSubscription = subscriptionData?.hasSubscription && subscriptionData?.status === 'active';

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <LanguageSelector />
            <span className="text-sm text-gray-600 dark:text-gray-400">{user?.name}</span>
            <Button variant="outline" onClick={logout}>
              {t('logout')}
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-8">{t('dashboard')}</h1>

        {/* Subscription Status */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>{t('subscriptionStatus')}</CardTitle>
          </CardHeader>
          <CardContent>
            {subLoading ? (
              <p>{t('loading')}</p>
            ) : hasActiveSubscription ? (
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-lg font-semibold text-green-600 dark:text-green-400">
                    {t('active')}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {t('allFeatures')}
                  </p>
                </div>
                <Link href="/subscription">
                  <Button variant="outline">{t('manageSubscription')}</Button>
                </Link>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-lg font-semibold text-red-600 dark:text-red-400">
                    {t('inactive')}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {t('subscriptionRequired')}
                  </p>
                </div>
                <Link href="/subscription">
                  <Button className="bg-gradient-to-r from-pink-500 to-purple-600">
                    {t('subscribeNow')}
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Link href="/characters/new">
            <Card className="cursor-pointer hover:border-pink-300 dark:hover:border-pink-700 transition-colors">
              <CardHeader>
                <Plus className="h-8 w-8 text-pink-500 mb-2" />
                <CardTitle>{t('createCharacter')}</CardTitle>
                <CardDescription>
                  {t('physicalAttributes')}, {t('styleAttributes')}, {t('personalityAttributes')}
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/generate">
            <Card className="cursor-pointer hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
              <CardHeader>
                <Image className="h-8 w-8 text-purple-500 mb-2" />
                <CardTitle>{t('generateImage')}</CardTitle>
                <CardDescription>
                  {t('imageGenerationDesc')}
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/gallery">
            <Card className="cursor-pointer hover:border-pink-300 dark:hover:border-pink-700 transition-colors">
              <CardHeader>
                <MessageCircle className="h-8 w-8 text-pink-500 mb-2" />
                <CardTitle>Galeria de Gerações</CardTitle>
                <CardDescription>
                  Visualize e baixe seu conteúdo gerado
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/ads/create">
            <Card className="cursor-pointer hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
              <CardHeader>
                <Sparkles className="h-8 w-8 text-purple-500 mb-2" />
                <CardTitle>Gerar Criativos</CardTitle>
                <CardDescription>
                  Crie anúncios para redes sociais
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>
        </div>

        {/* My Characters */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>{t('myCharacters')}</CardTitle>
              <Link href="/characters/new">
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  {t('createCharacter')}
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {charsLoading ? (
              <p>{t('loading')}</p>
            ) : characters && characters.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {characters.map((char) => (
                  <Link key={char.id} href={`/characters/${char.id}`}>
                    <Card className="cursor-pointer hover:border-pink-300 dark:hover:border-pink-700 transition-colors">
                      <CardHeader>
                        <CardTitle className="text-lg">{char.name}</CardTitle>
                        <CardDescription>
                          {char.archetype || t('archetype')}
                        </CardDescription>
                      </CardHeader>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>{t('createCharacter')}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

