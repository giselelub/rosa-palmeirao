# 🎯 COMECE AQUI - Guia Rápido para Colocar Online

Olá Gisele! 👋

Seu aplicativo **Rosa Palmeirão** está pronto! Agora vamos colocar online em poucos passos.

---

## ⏱️ Tempo Total: ~30 minutos

---

## 📝 Passo 1: Criar Conta no Hugging Face (5 min)

### O que é?
Hugging Face é um serviço que gera imagens com IA. Vamos usar para gerar as imagens dos personagens.

### Como fazer:

1. **Abra este link:** https://huggingface.co/join

2. **Clique em "Sign up"**

3. **Preencha:**
   - Email: `giselelubanco2@gmail.com`
   - Password: Crie uma senha (ex: `Rosa@2024Segura`)
   - Username: `rosa-palmeirao`

4. **Clique em "Create account"**

5. **Confirme seu email** (abra o email e clique no link)

6. **Gerar Token:**
   - Faça login em https://huggingface.co
   - Clique na sua foto (canto superior direito)
   - Clique em "Settings"
   - Clique em "Access Tokens"
   - Clique em "New token"
   - Nome: `Rosa Palmeirao API`
   - Tipo: `read`
   - Clique em "Generate token"
   - **Copie o token** (tipo: `hf_xxxxxxxxxxxxxxxxxxx`)

**GUARDE ESTE TOKEN! Você vai precisar dele.**

---

## 🗄️ Passo 2: Criar Banco de Dados (5 min)

### O que é?
Banco de dados é onde guardamos as informações dos usuários, personagens e conteúdo gerado.

### Como fazer:

1. **Abra este link:** https://vercel.com/dashboard

2. **Se não tiver conta, crie uma:**
   - Clique em "Sign Up"
   - Use sua conta GitHub (ou crie uma)

3. **Criar Banco de Dados:**
   - Clique em "Storage"
   - Clique em "Create Database"
   - Selecione "Postgres"
   - Escolha a região mais próxima (ex: São Paulo)
   - Clique em "Create"

4. **Copiar Connection String:**
   - Abra a aba "Postgres"
   - Clique em ".env.local"
   - **Copie toda a string** (tipo: `postgresql://user:password@host/database`)

**GUARDE ESTA STRING! Você vai precisar dela.**

---

## 🐙 Passo 3: Fazer Upload para GitHub (5 min)

### O que é?
GitHub é um serviço que guarda seu código. Vercel vai puxar o código de lá para fazer o deploy.

### Como fazer:

1. **Abra este link:** https://github.com/new

2. **Se não tiver conta, crie uma:**
   - Clique em "Sign up"
   - Use seu email: `giselelubanco2@gmail.com`

3. **Criar Repositório:**
   - Repository name: `rosa-palmeirao`
   - Description: `Aplicativo de influencers digitais`
   - Selecione "Public"
   - Clique em "Create repository"

4. **Fazer Upload do Código:**

Abra o terminal e execute:

```bash
cd /home/ubuntu/rosa-palmeirao

git init
git add .
git commit -m "Initial commit - Rosa Palmeirao"

git remote add origin https://github.com/SEU-USUARIO/rosa-palmeirao.git

git branch -M main
git push -u origin main
```

(Substitua `SEU-USUARIO` pelo seu username do GitHub)

---

## 🚀 Passo 4: Deploy na Vercel (10 min)

### Como fazer:

1. **Abra este link:** https://vercel.com/new

2. **Importar Repositório:**
   - Clique em "Import Git Repository"
   - Cole: `https://github.com/SEU-USUARIO/rosa-palmeirao.git`
   - Clique em "Import"

3. **Configurar Variáveis de Ambiente:**
   - Clique em "Environment Variables"
   - Adicione estas variáveis:

```
DATABASE_URL = (copie a string do Vercel Postgres)
HUGGING_FACE_API_KEY = (copie o token do Hugging Face)
VITE_APP_TITLE = Rosa Palmeirão
NODE_ENV = production
```

4. **Fazer Deploy:**
   - Clique em "Deploy"
   - Aguarde 2-5 minutos

5. **Seu Link:**
   - Quando terminar, você receberá um link como:
   - `https://rosa-palmeirao.vercel.app`

---

## ✅ Passo 5: Testar (5 min)

1. **Abra seu link:** `https://rosa-palmeirao.vercel.app`

2. **Fazer Cadastro:**
   - Clique em "Cadastre-se"
   - Email: `giselelubanco2@gmail.com`
   - Senha: Crie uma
   - Clique em "Cadastrar"

3. **Fazer Login:**
   - Use o email e senha que criou

4. **Testar Geração:**
   - Clique em "Criar Novo Personagem"
   - Preencha os dados
   - Clique em "Salvar"
   - Clique no ícone de câmera
   - Clique em "Gerar Imagem"
   - Aguarde 30-60 segundos
   - Você deve ver uma imagem gerada!

---

## 🎉 Pronto!

Seu app está online e funcionando!

**Seu link:** `https://rosa-palmeirao.vercel.app`

---

## 📊 Resumo do que você tem:

✅ **Autenticação** - Login e cadastro  
✅ **Criar Personagens** - Com 5 passos  
✅ **Gerar Imagens** - Com IA  
✅ **Gerar Vídeos** - De dança  
✅ **Chat** - Normal e picante  
✅ **Gerar Criativos** - Para redes sociais  
✅ **Galeria** - Visualizar tudo  
✅ **Assinatura** - Sistema de pagamento  
✅ **Teste Grátis** - 1 teste de cada função  

---

## 💡 Dicas Importantes

1. **Teste Grátis:** Usuários podem gerar 1 imagem, 1 vídeo, 3 chats e 1 criativo sem pagar
2. **Sem Download:** Só assinantes podem fazer download
3. **Assinatura:** Configure os preços no painel de administração
4. **Suporte:** Se tiver problemas, verifique os logs na Vercel

---

## 🆘 Se Tiver Problemas

### Erro ao fazer deploy?
- Verifique se todas as variáveis estão configuradas
- Verifique se o repositório GitHub está público
- Tente fazer novo deploy

### Imagem não gera?
- Verifique se o token do Hugging Face está correto
- Aguarde 30-60 segundos
- Tente novamente

### Banco de dados não conecta?
- Verifique se a string DATABASE_URL está correta
- Verifique se o banco está ativo na Vercel

---

## 📞 Próximos Passos

1. ✅ Compartilhe o link com seus amigos
2. ✅ Configure os preços das assinaturas
3. ✅ Customize o design (cores, logo, etc)
4. ✅ Comece a ganhar com assinaturas!

---

**Parabéns! 🎊 Seu app está online!**

Se precisar de ajuda, entre em contato.

---

**Data:** Outubro 2025  
**Status:** ✅ Pronto para Usar

