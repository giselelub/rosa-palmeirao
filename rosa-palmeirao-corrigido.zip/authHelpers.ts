/**
 * Helpers para autenticação com e-mail e senha
 * Funções simples para hash de senha e verificação
 */

/**
 * Função simples de hash de senha (sem dependências externas)
 * Em produção, use bcrypt ou argon2
 */
export function hashPassword(password: string): string {
  // Implementação simples: em produção use bcrypt
  // Para agora, vamos usar uma abordagem básica
  const crypto = require('crypto');
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

/**
 * Verifica se a senha está correta
 */
export function verifyPassword(password: string, hashedPassword: string): boolean {
  const crypto = require('crypto');
  const [salt, hash] = hashedPassword.split(':');
  const newHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return hash === newHash;
}

/**
 * Valida se um email é válido
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Valida se a senha é forte
 */
export function isStrongPassword(password: string): boolean {
  // Mínimo 6 caracteres
  if (password.length < 6) return false;
  
  // Deve ter pelo menos um número
  if (!/\d/.test(password)) return false;
  
  // Deve ter pelo menos uma letra
  if (!/[a-zA-Z]/.test(password)) return false;
  
  return true;
}

/**
 * Gera um token de sessão simples
 */
export function generateSessionToken(): string {
  const crypto = require('crypto');
  return crypto.randomBytes(32).toString('hex');
}

