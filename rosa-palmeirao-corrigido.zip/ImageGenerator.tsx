import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Download, Share2, AlertCircle, Loader, Lock } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import TrialLimitModal from "./TrialLimitModal";

const IMAGE_SIZES = {
  small: { label: "Pequena (512x512)", value: "512x512" },
  medium: { label: "Média (768x768)", value: "768x768" },
  large: { label: "Grande (1024x1024)", value: "1024x1024" },
  xlarge: { label: "Extra Grande (1536x1536)", value: "1536x1536" },
};

const CONTENT_TYPES = {
  glamour: { label: "🌸 Glamour", desc: "Elegante e sofisticado" },
  spicy: { label: "🌶️ Spicy", desc: "Ousado e provocante" },
  adult: { label: "🔞 Adult +18", desc: "Conteúdo adulto sem censura" },
};

export default function ImageGenerator() {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/generate-image/:characterId");

  const characterId = params?.characterId ? parseInt(params.characterId) : null;

  const [size, setSize] = useState<keyof typeof IMAGE_SIZES>("large");
  const [contentType, setContentType] = useState<"glamour" | "spicy" | "adult">("glamour");
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);
  const [showTrialModal, setShowTrialModal] = useState(false);
  const [trialInfo, setTrialInfo] = useState<any>(null);

  // Buscar personagem
  const { data: character } = trpc.character.save.getById.useQuery(
    { id: characterId || 0 },
    { enabled: !!characterId }
  );

  // Verificar limite de teste
  const { data: subscriptionStatus } = trpc.subscriptionLimit.getSubscriptionStatus.useQuery();
  const { data: canUseFeature } = trpc.subscriptionLimit.canUseFeature.useQuery(
    { feature: "generateImage" },
    { enabled: !!characterId }
  );

  // Registrar uso
  const recordUsageMutation = trpc.subscriptionLimit.recordFeatureUsage.useMutation();

  // Gerar imagem
  const generateImageMutation = trpc.contentGeneration.generateImage.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setGeneratedImage(data.imageUrl);
        recordUsageMutation.mutate({ feature: "generateImage" });
        
        // Mostrar modal de limite
        if (canUseFeature) {
          setTrialInfo(canUseFeature);
          setShowTrialModal(true);
        }
      }
    },
    onError: (error) => {
      alert(error.message || "Erro ao gerar imagem");
    },
  });

  const handleGenerateImage = async () => {
    if (!characterId) return;
    if (!canUseFeature?.allowed) {
      alert(canUseFeature?.reason || "Você não tem permissão para usar esta funcionalidade");
      return;
    }

    await generateImageMutation.mutateAsync({
      characterId,
      contentType,
    });
  };

  const handleDownload = async () => {
    if (!generatedImage) return;

    // Verificar se pode fazer download
    if (!subscriptionStatus?.hasSubscription) {
      setTrialInfo(canUseFeature);
      setShowTrialModal(true);
      return;
    }

    setDownloading(true);
    try {
      const response = await fetch(generatedImage);
      const blob = await response.blob();
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `imagem_${character?.name}_${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert("Erro ao baixar imagem");
    } finally {
      setDownloading(false);
    }
  };

  const handleShare = () => {
    if (!generatedImage) return;

    if (navigator.share) {
      navigator.share({
        title: `Confira a imagem de ${character?.name}!`,
        url: generatedImage,
      });
    } else {
      navigator.clipboard.writeText(generatedImage);
      alert("Link copiado para a área de transferência!");
    }
  };

  if (!characterId) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900 flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">Personagem não encontrado</p>
            <Link href="/dashboard">
              <Button className="w-full mt-4">Voltar ao Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
        </div>
      </header>

      <div className="container py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Gerar Imagem</h1>
          <p className="text-gray-600 dark:text-gray-400">
            {character?.name} - Crie imagens personalizadas
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Configuration Panel */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Configurações</CardTitle>
                <CardDescription>Personalize sua imagem</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Content Type Selection */}
                <div>
                  <label className="block text-sm font-medium mb-3">Tipo de Conteúdo</label>
                  <div className="space-y-2">
                    {Object.entries(CONTENT_TYPES).map(([key, { label, desc }]) => (
                      <label
                        key={key}
                        className={`flex items-center p-3 border rounded-lg cursor-pointer transition ${
                          contentType === key
                            ? "border-pink-500 bg-pink-50 dark:bg-pink-900/20"
                            : "border-gray-200 dark:border-gray-700 hover:border-pink-300"
                        }`}
                      >
                        <input
                          type="radio"
                          name="contentType"
                          value={key}
                          checked={contentType === key}
                          onChange={(e) => setContentType(e.target.value as any)}
                          className="mr-3"
                        />
                        <div>
                          <div className="font-medium">{label}</div>
                          <div className="text-xs text-gray-500">{desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>

                  {contentType === "adult" && (
                    <div className="mt-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded text-sm text-red-700 dark:text-red-300 flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                      <span>Conteúdo +18 - Apenas para maiores de idade</span>
                    </div>
                  )}
                </div>

                {/* Size Selection */}
                <div>
                  <label className="block text-sm font-medium mb-3">Tamanho da Imagem</label>
                  <div className="space-y-2">
                    {Object.entries(IMAGE_SIZES).map(([key, { label, value }]) => (
                      <label
                        key={key}
                        className={`flex items-center p-2 border rounded cursor-pointer transition ${
                          size === key
                            ? "border-pink-500 bg-pink-50 dark:bg-pink-900/20"
                            : "border-gray-200 dark:border-gray-700 hover:border-pink-300"
                        }`}
                      >
                        <input
                          type="radio"
                          name="size"
                          value={key}
                          checked={size === key}
                          onChange={(e) => setSize(e.target.value as any)}
                          className="mr-3"
                        />
                        <span className="text-sm">{label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Generate Button */}
                <Button
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                  onClick={handleGenerateImage}
                  disabled={generateImageMutation.isPending}
                >
                  {generateImageMutation.isPending ? (
                    <>
                      <Loader className="h-4 w-4 mr-2 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    "Gerar Imagem"
                  )}
                </Button>

                <Link href="/dashboard">
                  <Button variant="outline" className="w-full">
                    Voltar
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Image Preview */}
          <div className="lg:col-span-2">
            {generatedImage ? (
              <Card>
                <CardHeader>
                  <CardTitle>Imagem Gerada</CardTitle>
                  <CardDescription>
                    {IMAGE_SIZES[size].label} - {CONTENT_TYPES[contentType].label}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Image Display */}
                  <div className="bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                    <img
                      src={generatedImage}
                      alt="Generated"
                      className="w-full h-auto"
                    />
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      className={subscriptionStatus?.hasSubscription ? "bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700" : "bg-gray-400 cursor-not-allowed"}
                      onClick={handleDownload}
                      disabled={downloading || !subscriptionStatus?.hasSubscription}
                    >
                      {subscriptionStatus?.hasSubscription ? (
                        <>
                          <Download className="h-4 w-4 mr-2" />
                          {downloading ? "Baixando..." : "Baixar"}
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-2" />
                          Bloqueado
                        </>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleShare}
                    >
                      <Share2 className="h-4 w-4 mr-2" />
                      Compartilhar
                    </Button>
                  </div>

                  {/* Generate Another */}
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setGeneratedImage(null)}
                  >
                    Gerar Outra Imagem
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-12 pb-12 text-center">
                  <Sparkles className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Selecione as configurações e clique em "Gerar Imagem" para começar
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Trial Limit Modal */}
      <TrialLimitModal
        feature="Gerar Imagem"
        isOpen={showTrialModal}
        onClose={() => setShowTrialModal(false)}
        hasSubscription={subscriptionStatus?.hasSubscription || false}
        trialUsed={trialInfo?.trialUsed || 0}
        trialLimit={trialInfo?.trialLimit || 1}
        canDownload={subscriptionStatus?.hasSubscription || false}
      />
    </div>
  );
}

