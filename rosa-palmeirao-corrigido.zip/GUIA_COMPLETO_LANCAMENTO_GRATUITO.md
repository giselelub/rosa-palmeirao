# 🚀 Guia Completo: Lançamento Gratuito do Rosa Palmeirão

Este guia fornece instruções passo a passo para lançar seu aplicativo **completamente gratuito** usando serviços com planos gratuitos generosos.

---

## 📋 Resumo da Solução Gratuita

| Componente | Serviço | Plano | Limite Gratuito |
| :--- | :--- | :--- | :--- |
| **Banco de Dados** | Neon (PostgreSQL) | Free | 3 projetos, 0.5 GB storage |
| **Backend** | Render | Free Tier | 750 horas/mês, 0.5 GB RAM |
| **Frontend** | Vercel | Hobby | Builds ilimitados, 100 GB bandwidth/mês |
| **Imagens** | Hugging Face | Free | API gratuita com limite de requisições |
| **Chat/IA** | OpenAI | Free Trial | $5 crédito inicial |
| **Email** | Resend | Free | 100 emails/dia |
| **Storage de Imagens** | Cloudinary | Free | 25 créditos/mês |

---

## ✅ Pré-requisitos

Antes de começar, você precisará de:

1. **Conta GitHub** (para conectar repositórios)
2. **Conta Neon** (para banco de dados PostgreSQL)
3. **Conta Render** (para hospedagem do backend)
4. **Conta Vercel** (para hospedagem do frontend)
5. **Chaves de API** dos serviços (Hugging Face, OpenAI, Cloudinary, Resend, PayPal)

---

## 🔧 Passo 1: Configurar o Banco de Dados (Neon)

### 1.1 Criar uma Conta no Neon

1. Acesse [console.neon.tech](https://console.neon.tech)
2. Clique em **"Sign Up"** e crie uma conta usando seu email ou GitHub
3. Confirme seu email

### 1.2 Criar um Novo Projeto

1. Na dashboard do Neon, clique em **"New Project"**
2. Preencha os detalhes:
   - **Project Name:** `rosa-palmeirao`
   - **Database Name:** `rosa_db`
   - **Region:** Escolha a região mais próxima de você (ex: `us-east-1` para América do Norte)
3. Clique em **"Create Project"**

### 1.3 Obter a String de Conexão

1. Após criar o projeto, você verá a página de conexão
2. Clique em **"Connection string"** (ou procure por "Connection Details")
3. Copie a string de conexão (deve parecer com: `postgresql://user:password@ep-xxxxx.us-east-1.aws.neon.tech/rosa_db?sslmode=require`)
4. **Salve esta string em um local seguro** - você precisará dela em breve

### 1.4 Atualizar o .env Local

1. Abra o arquivo `.env` na raiz do seu projeto
2. Substitua a linha `DATABASE_URL` pela string de conexão do Neon:

```bash
DATABASE_URL="postgresql://user:password@ep-xxxxx.us-east-1.aws.neon.tech/rosa_db?sslmode=require"
```

---

## 🏗️ Passo 2: Preparar o Projeto Localmente

### 2.1 Instalar Dependências

```bash
cd /caminho/do/seu/projeto
npm install
```

### 2.2 Gerar Migrações do Banco de Dados

```bash
npm run db:generate
```

Isso criará os arquivos de migração baseado no seu `schema.ts`.

### 2.3 Executar Migrações

```bash
npm run db:push
```

Isso criará as tabelas no banco de dados Neon.

### 2.4 Testar Localmente

```bash
npm run dev
```

Seu aplicativo deve estar rodando em `http://localhost:5000` (backend) e `http://localhost:5173` (frontend).

---

## 🌐 Passo 3: Deploy do Frontend (Vercel)

### 3.1 Preparar o Repositório GitHub

1. Se ainda não tem, crie um repositório GitHub para seu projeto:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Rosa Palmeirão"
   git branch -M main
   git remote add origin https://github.com/seu-usuario/rosa-palmeirao.git
   git push -u origin main
   ```

### 3.2 Conectar ao Vercel

1. Acesse [vercel.com](https://vercel.com)
2. Clique em **"Sign Up"** e crie uma conta usando GitHub
3. Clique em **"New Project"**
4. Selecione seu repositório `rosa-palmeirao`
5. Clique em **"Import"**

### 3.3 Configurar Variáveis de Ambiente

Na página de configuração do Vercel:

1. Vá para **"Environment Variables"**
2. Adicione as seguintes variáveis:
   - `VITE_API_URL`: `https://seu-backend-render.onrender.com` (você obterá isso no Passo 4)
   - `VITE_APP_TITLE`: `Rosa Palmeirão`
   - Qualquer outra variável necessária para o frontend

3. Clique em **"Deploy"**

O Vercel fará o deploy automaticamente. Você receberá um URL como `https://rosa-palmeirao.vercel.app`.

---

## ⚙️ Passo 4: Deploy do Backend (Render)

### 4.1 Criar um Serviço no Render

1. Acesse [render.com](https://render.com)
2. Clique em **"Sign Up"** e crie uma conta usando GitHub
3. Clique em **"New +"** > **"Web Service"**
4. Selecione seu repositório `rosa-palmeirao`
5. Preencha os detalhes:
   - **Name:** `rosa-palmeirao-backend`
   - **Environment:** `Node`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Plan:** Free

### 4.2 Configurar Variáveis de Ambiente

Na página de configuração do Render:

1. Vá para **"Environment"**
2. Adicione as seguintes variáveis:
   - `DATABASE_URL`: Cole a string de conexão do Neon
   - `NODE_ENV`: `production`
   - `SERVER_PORT`: `5000`
   - `SESSION_SECRET`: Gere uma chave segura (use `openssl rand -hex 32`)
   - `OPENAI_API_KEY`: Sua chave da OpenAI
   - `HUGGING_FACE_API_KEY`: Sua chave do Hugging Face
   - `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`: Suas credenciais
   - `RESEND_API_KEY`: Sua chave do Resend
   - `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`: Suas credenciais do PayPal
   - `VITE_API_URL`: `https://seu-backend-render.onrender.com` (será gerado após o deploy)

3. Clique em **"Create Web Service"**

O Render fará o deploy. Você receberá um URL como `https://rosa-palmeirao-backend.onrender.com`.

### 4.3 Atualizar o Frontend com a URL do Backend

Volte ao Vercel e atualize a variável `VITE_API_URL` com a URL do Render que você recebeu.

---

## 🔑 Passo 5: Configurar as Chaves de API

### 5.1 Hugging Face (Geração de Imagens)

1. Acesse [huggingface.co](https://huggingface.co)
2. Crie uma conta ou faça login
3. Vá para **Settings** > **Access Tokens**
4. Clique em **"New token"**
5. Copie o token e adicione ao `.env` como `HUGGING_FACE_API_KEY`

### 5.2 OpenAI (Chat e Processamento)

1. Acesse [platform.openai.com](https://platform.openai.com)
2. Crie uma conta ou faça login
3. Vá para **API keys**
4. Clique em **"Create new secret key"**
5. Copie a chave e adicione ao `.env` como `OPENAI_API_KEY`

### 5.3 Cloudinary (Storage de Imagens)

1. Acesse [cloudinary.com](https://cloudinary.com)
2. Crie uma conta gratuita
3. Vá para **Dashboard**
4. Copie suas credenciais (`Cloud Name`, `API Key`, `API Secret`)
5. Adicione ao `.env`

### 5.4 Resend (Email)

1. Acesse [resend.com](https://resend.com)
2. Crie uma conta
3. Vá para **API Keys**
4. Clique em **"Create API Key"**
5. Copie a chave e adicione ao `.env` como `RESEND_API_KEY`

### 5.5 PayPal (Pagamentos)

1. Acesse [developer.paypal.com](https://developer.paypal.com)
2. Crie uma conta de desenvolvedor
3. Vá para **Apps & Credentials**
4. Copie seu `Client ID` e `Client Secret`
5. Adicione ao `.env` (use `PAYPAL_MODE="sandbox"` para testes)

---

## 🧪 Passo 6: Testar o Aplicativo Completo

### 6.1 Testar Localmente

```bash
npm run dev
```

Acesse `http://localhost:5173` no navegador e teste as funcionalidades:
- Criar conta
- Gerar imagens
- Criar personagens
- Chat com IA

### 6.2 Testar em Produção

1. Acesse sua URL do Vercel: `https://rosa-palmeirao.vercel.app`
2. Teste as mesmas funcionalidades
3. Verifique os logs no Render e Vercel se houver erros

---

## 💰 Implementar Assinaturas Pagas

Agora que seu aplicativo está lançado gratuitamente, você pode implementar assinaturas pagas:

### 6.1 Usar PayPal para Assinaturas

O seu código já tem suporte para PayPal. Configure:

1. Vá para o PayPal Developer Dashboard
2. Crie um plano de assinatura
3. Adicione os IDs dos planos ao seu código
4. Implemente a lógica de cobrança

### 6.2 Usar Stripe (Alternativa)

Se preferir Stripe:

1. Crie uma conta em [stripe.com](https://stripe.com)
2. Obtenha suas chaves de API
3. Implemente a integração no seu código

---

## 📊 Monitorar Uso e Limites

### Neon (Banco de Dados)

- Acesse [console.neon.tech](https://console.neon.tech)
- Verifique o uso de storage em **Project Settings**

### Render (Backend)

- Acesse [render.com](https://render.com)
- Verifique o uso de horas em **Billing**

### Vercel (Frontend)

- Acesse [vercel.com](https://vercel.com)
- Verifique o uso de bandwidth em **Analytics**

### OpenAI (IA)

- Acesse [platform.openai.com](https://platform.openai.com)
- Verifique o uso de tokens em **Usage**

---

## 🆘 Solução de Problemas

### Erro: "DATABASE_URL is not set"

- Verifique se a variável de ambiente está configurada no Render
- Verifique se a string de conexão do Neon está correta

### Erro: "Connection refused"

- Verifique se o backend está rodando no Render
- Verifique se a URL do backend está correta no frontend

### Erro: "API key invalid"

- Verifique se as chaves de API estão corretas
- Verifique se as chaves estão configuradas no Render

### Aplicativo lento

- Pode ser devido ao plano gratuito do Render (0.5 GB RAM)
- Considere fazer upgrade para um plano pago se necessário

---

## 🎉 Próximos Passos

1. **Coletar feedback** dos usuários
2. **Implementar melhorias** baseado no feedback
3. **Escalar para planos pagos** conforme crescimento
4. **Monitorar métricas** de uso e performance
5. **Otimizar custos** quando necessário

---

## 📞 Suporte

Se encontrar problemas:

1. Verifique os logs no Render: **Logs** > **Service Logs**
2. Verifique os logs no Vercel: **Deployments** > **Logs**
3. Verifique o status do Neon em [status.neon.tech](https://status.neon.tech)
4. Procure por soluções na documentação oficial dos serviços

---

**Boa sorte com o lançamento do Rosa Palmeirão! 🚀**

