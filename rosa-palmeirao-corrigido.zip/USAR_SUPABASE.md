# 🚀 Usar Supabase (PostgreSQL Gratuito) - Rosa Palmeirão

Supabase oferece PostgreSQL **100% GRATUITO** e é perfeito para seu app!

---

## 📋 Passo 1: Criar Conta Supabase (5 minutos)

### 1.1 Abrir Supabase

1. Abra este link: **https://supabase.com**
2. Clique em **"Start your project"** ou **"Sign up"**

### 1.2 Criar Conta

1. Preencha com seus dados:
   - Email: `giselelubanco2@gmail.com`
   - Password: Crie uma senha forte
2. Clique em **"Sign up"**
3. **Confirme seu email** (abra o email e clique no link)

### 1.3 Criar Projeto

1. Faça login em: **https://app.supabase.com**
2. Clique em **"New project"** ou **"Create a new project"**
3. Preencha:
   - **Project name:** `rosa-palmeirao`
   - **Database password:** Crie uma senha forte
   - **Region:** Escolha **"South America (São Paulo)"** ou **"US East (N. Virginia)"**
   - **Plan:** Deixe como **"Free"** (gratuito)
4. Clique em **"Create new project"**
5. Aguarde alguns minutos (vai criar o banco)

### 1.4 Copiar Connection String

1. Quando o projeto for criado, procure por **"Database"** no menu esquerdo
2. Clique em **"Database"**
3. Procure por **"Connection string"** ou **"Connection pooling"**
4. Escolha **"Connection pooling"** (mais rápido)
5. Copie a string que começa com: `postgresql://`
6. **Guarde em um lugar seguro**

---

## 🌐 Passo 2: Fazer Deploy na Vercel (10 minutos)

### 2.1 Ir para Novo Projeto

1. Abra: **https://vercel.com/new**
2. Clique em **"Import Git Repository"**

### 2.2 Importar Repositório

1. Cole este link: `https://github.com/giselelub/rosa-palmeirao`
2. Clique em **"Import"**

### 2.3 Configurar Projeto

1. Preencha:
   - **Project Name:** `rosa-palmeirao`
   - **Framework:** Deixe como está

### 2.4 Adicionar Variáveis de Ambiente

1. Procure por: **"Environment Variables"**
2. Clique em **"Add New"** para adicionar cada variável

3. **Adicione estas variáveis:**

   **Variável 1:**
   - Name: `DATABASE_URL`
   - Value: (Cole a connection string do Supabase)
   - Clique em "Add"

   **Variável 2:**
   - Name: `HUGGING_FACE_API_KEY`
   - Value: `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`
   - Clique em "Add"

   **Variável 3:**
   - Name: `VITE_APP_TITLE`
   - Value: `Rosa Palmeirão`
   - Clique em "Add"

   **Variável 4:**
   - Name: `NODE_ENV`
   - Value: `production`
   - Clique em "Add"

### 2.5 Fazer Deploy

1. Clique em **"Deploy"** (botão grande)
2. Aguarde 3-5 minutos
3. Quando terminar, você receberá um link:
   ```
   https://rosa-palmeirao.vercel.app
   ```

---

## ✅ Passo 3: Testar o App (5 minutos)

### 3.1 Acessar o App

1. Clique no link que você recebeu
2. Você deve ver a página inicial do Rosa Palmeirão

### 3.2 Fazer Cadastro

1. Clique em **"Cadastre-se"**
2. Preencha:
   - Email: `giselelubanco2@gmail.com`
   - Senha: Crie uma senha
   - Confirmar: Digite a mesma senha
3. Clique em **"Cadastrar"**

### 3.3 Fazer Login

1. Clique em **"Entrar"**
2. Use o email e senha que cadastrou
3. Você deve ver o **Dashboard**

### 3.4 Testar Geração

1. Clique em **"Criar Novo Personagem"**
2. Preencha os dados
3. Clique em **"Salvar"**
4. Clique no ícone de câmera
5. Clique em **"Gerar Imagem"**
6. Aguarde 30-60 segundos
7. Você deve ver uma imagem gerada!

---

## 🎉 Pronto!

Seu app está online! 🚀

**Link:** `https://rosa-palmeirao.vercel.app`

---

## 📊 Resumo:

| Passo | Tempo | O que fez |
|-------|-------|----------|
| 1 | 5 min | Criar banco Supabase |
| 2 | 10 min | Fazer deploy Vercel |
| 3 | 5 min | Testar app |
| **Total** | **20 min** | **App online!** |

---

## 💰 Custos:

- ✅ Supabase: **GRATUITO** (PostgreSQL)
- ✅ Vercel: **GRATUITO** (Hospedagem)
- ✅ Hugging Face: **GRATUITO** (Geração de imagens)
- ✅ **Total: R$ 0,00** 🎉

---

## 🆘 Se Tiver Problemas

### "Não consigo copiar a connection string"
- Procure por um botão "Copy" ou "Show"
- Clique nele
- A string vai aparecer

### "Erro ao fazer deploy"
- Verifique se a DATABASE_URL está correta
- Tente fazer novo deploy

### "Imagem não gera"
- Aguarde 30-60 segundos
- Tente novamente
- Verifique o token do Hugging Face

---

## 📝 Links Úteis

- **Supabase:** https://app.supabase.com
- **Vercel:** https://vercel.com/dashboard
- **Seu App:** https://rosa-palmeirao.vercel.app

---

**Boa sorte! 💪 Você consegue!**

