import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";

// Templates de headlines por plataforma
const HEADLINE_TEMPLATES = {
  facebook: [
    "🔥 {product} - A Solução que Você Esperava!",
    "✨ Descubra {product} - Transforme Sua Vida",
    "💎 {product}: Qualidade Premium com Preço Acessível",
    "⚡ Não Perca! {product} em Oferta Especial",
    "🎯 {product} - Perfeito Para Você",
    "💫 {product} - Sua Melhor Escolha",
    "🌟 Aproveite {product} Agora",
    "👑 {product} - Exclusividade Garantida",
  ],
  tiktok: [
    "POV: Você encontrou {product} 🤯",
    "{product} mudou minha vida! 💯",
    "Todos estão usando {product} agora 🔥",
    "Você PRECISA de {product} 😍",
    "{product} é INSANO! 🚀",
    "Não acredito que {product} é tão bom 😱",
    "Meu favorito agora é {product} ✨",
    "{product} > tudo 💪",
  ],
  instagram: [
    "✨ Novo: {product}",
    "🌟 {product} - Seu Novo Favorito",
    "💫 Descubra a Magia de {product}",
    "🎀 {product} - Perfeição em Cada Detalhe",
    "👑 {product} - Exclusividade Garantida",
    "💎 {product} - Qualidade Superior",
    "🌸 {product} - Lindeza Pura",
    "✨ {product} - Imprescindível",
  ],
  kwai: [
    "🔥 {product} - Imperdível!",
    "💰 {product} com Desconto Especial",
    "⭐ {product} - Mais Vendido",
    "🎁 Aproveite {product} Agora",
    "✅ {product} - Recomendado",
    "🚀 {product} - Sucesso Total",
    "💝 {product} - Vale Muito a Pena",
    "🎉 {product} - Oferta Imperdível",
  ],
};

// Templates de descrição por plataforma
const DESCRIPTION_TEMPLATES = {
  facebook: [
    "Qualidade superior, preço justo. Aproveite a promoção limitada!",
    "Milhares de clientes satisfeitos. Seja o próximo!",
    "Frete grátis em compras acima de R$ 100. Compre agora!",
    "Garantia de satisfação ou seu dinheiro de volta.",
    "Oferta válida por tempo limitado. Não perca!",
    "Entrega rápida em todo o Brasil.",
    "Parcelado em até 12x sem juros.",
    "Compre com confiança e segurança.",
  ],
  tiktok: [
    "Clique no link e aproveita! 🎉",
    "Link na bio! Não deixa de conferir 👆",
    "Disponível agora! Compra já! 💳",
    "Oferta especial só para você! ✨",
    "Vem conferir! 👇",
    "Tá esperando o quê? 🚀",
    "Rápido, tá acabando! ⚡",
    "Você vai amar! 💕",
  ],
  instagram: [
    "Disponível agora em nossa loja online.",
    "Clique no link da bio para comprar.",
    "Frete grátis para todo Brasil!",
    "Parcelado em até 12x.",
    "Compre com segurança e confiança.",
    "Qualidade garantida.",
    "Entrega rápida.",
    "Satisfação 100% garantida.",
  ],
  kwai: [
    "Compra agora com desconto especial!",
    "Frete grátis para sua região!",
    "Aproveita enquanto durar o estoque!",
    "Paga com segurança na plataforma!",
    "Entrega rápida garantida!",
    "Promoção imperdível!",
    "Qualidade premium!",
    "Melhor preço do mercado!",
  ],
};

// Templates de CTA por plataforma
const CTA_TEMPLATES = {
  facebook: ["Compre Agora", "Saiba Mais", "Aproveite", "Clique Aqui", "Conheça Mais", "Explore", "Descubra"],
  tiktok: ["Compra Já", "Confira", "Vem Ver", "Clica Aqui", "Aproveita", "Tá Aqui", "Bora Lá"],
  instagram: ["Compre Agora", "Saiba Mais", "Visite", "Clique", "Descubra", "Explore", "Conheça"],
  kwai: ["Compra Agora", "Aproveita", "Vem Cá", "Confira", "Clica Aqui", "Bora", "Tá Aqui"],
};

// Validation schema
const generateCreativeSchema = z.object({
  platform: z.enum(["facebook", "tiktok", "instagram", "kwai"]),
  productName: z.string().min(1, "Nome do produto é obrigatório"),
  imageUrl: z.string().optional(),
  size: z.string().optional(),
});

export const adCreativeRouter = router({
  /**
   * Gerar criativo para anúncio
   */
  generate: publicProcedure
    .input(generateCreativeSchema)
    .mutation(async ({ input }) => {
      try {
        const { platform, productName, imageUrl, size } = input;

        // Selecionar templates aleatórios
        const headlineTemplate =
          HEADLINE_TEMPLATES[platform][
            Math.floor(Math.random() * HEADLINE_TEMPLATES[platform].length)
          ];
        const descriptionTemplate =
          DESCRIPTION_TEMPLATES[platform][
            Math.floor(Math.random() * DESCRIPTION_TEMPLATES[platform].length)
          ];
        const ctaTemplate =
          CTA_TEMPLATES[platform][Math.floor(Math.random() * CTA_TEMPLATES[platform].length)];

        // Substituir placeholder do produto
        const headline = headlineTemplate.replace("{product}", productName);

        return {
          success: true,
          creative: {
            platform,
            productName,
            imageUrl: imageUrl || null,
            size: size || "1080x1080",
            headline,
            description: descriptionTemplate,
            ctaText: ctaTemplate,
            generatedAt: new Date().toISOString(),
          },
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao gerar criativo");
      }
    }),

  /**
   * Gerar múltiplos criativos
   */
  generateBatch: publicProcedure
    .input(z.object({
      platform: z.enum(["facebook", "tiktok", "instagram", "kwai"]),
      productName: z.string().min(1),
      quantity: z.number().min(1).max(10),
    }))
    .mutation(async ({ input }) => {
      try {
        const { platform, productName, quantity } = input;
        const creatives = [];

        for (let i = 0; i < quantity; i++) {
          const headlineTemplate =
            HEADLINE_TEMPLATES[platform][
              Math.floor(Math.random() * HEADLINE_TEMPLATES[platform].length)
            ];
          const descriptionTemplate =
            DESCRIPTION_TEMPLATES[platform][
              Math.floor(Math.random() * DESCRIPTION_TEMPLATES[platform].length)
            ];
          const ctaTemplate =
            CTA_TEMPLATES[platform][Math.floor(Math.random() * CTA_TEMPLATES[platform].length)];

          creatives.push({
            id: i + 1,
            headline: headlineTemplate.replace("{product}", productName),
            description: descriptionTemplate,
            ctaText: ctaTemplate,
          });
        }

        return {
          success: true,
          platform,
          productName,
          quantity,
          creatives,
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao gerar criativos");
      }
    }),

  /**
   * Obter templates disponíveis
   */
  getTemplates: publicProcedure
    .input(z.object({
      platform: z.enum(["facebook", "tiktok", "instagram", "kwai"]),
    }))
    .query(({ input }) => {
      return {
        platform: input.platform,
        headlines: HEADLINE_TEMPLATES[input.platform],
        descriptions: DESCRIPTION_TEMPLATES[input.platform],
        ctas: CTA_TEMPLATES[input.platform],
      };
    }),
});

