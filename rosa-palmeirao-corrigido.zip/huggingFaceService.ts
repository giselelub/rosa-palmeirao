/**
 * Serviço de integração com Hugging Face para geração de imagens
 * Documentação: https://huggingface.co/docs/api-inference
 */

const HF_API_KEY = process.env.HUGGING_FACE_API_KEY;
const HF_API_URL = "https://api-inference.huggingface.co/models";

// Modelos disponíveis
const MODELS = {
  // Modelo rápido e gratuito
  STABLE_DIFFUSION_2: "stabilityai/stable-diffusion-2",
  // Modelo mais rápido
  STABLE_DIFFUSION_TURBO: "stabilityai/stable-diffusion-turbo",
  // Modelo com melhor qualidade
  REALISTIC_VISION: "SG161222/Realistic_Vision_V6.0_B1_noVAE",
};

interface GenerateImageParams {
  prompt: string;
  negativePrompt?: string;
  numInferenceSteps?: number;
  guidanceScale?: number;
  height?: number;
  width?: number;
}

/**
 * Gerar imagem usando Hugging Face
 */
export async function generateImageWithHuggingFace(
  params: GenerateImageParams
): Promise<Buffer> {
  try {
    if (!HF_API_KEY) {
      throw new Error("HUGGING_FACE_API_KEY não configurada");
    }

    const {
      prompt,
      negativePrompt = "low quality, blurry, distorted",
      numInferenceSteps = 20,
      guidanceScale = 7.5,
      height = 512,
      width = 512,
    } = params;

    const payload = {
      inputs: prompt,
      parameters: {
        negative_prompt: negativePrompt,
        num_inference_steps: numInferenceSteps,
        guidance_scale: guidanceScale,
        height,
        width,
      },
    };

    console.log("Gerando imagem com Hugging Face...", { prompt, height, width });

    const response = await fetch(
      `${HF_API_URL}/${MODELS.STABLE_DIFFUSION_2}`,
      {
        headers: {
          Authorization: `Bearer ${HF_API_KEY}`,
        },
        method: "POST",
        body: JSON.stringify(payload),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error("Erro ao gerar imagem:", error);
      throw new Error(`Hugging Face API error: ${response.status}`);
    }

    const imageBuffer = await response.arrayBuffer();
    return Buffer.from(imageBuffer);
  } catch (error) {
    console.error("Erro na geração de imagem:", error);
    throw error;
  }
}

/**
 * Converter Buffer para Data URL
 */
export function bufferToDataUrl(buffer: Buffer, mimeType: string = "image/png"): string {
  const base64 = buffer.toString("base64");
  return `data:${mimeType};base64,${base64}`;
}

/**
 * Gerar prompt otimizado para o modelo
 */
export function optimizePrompt(basePrompt: string, contentType: "glamour" | "spicy" | "adult"): string {
  const qualityModifiers = "masterpiece, best quality, 8K, ultra detailed, professional photography";

  const styleModifiers = {
    glamour: "elegant, sophisticated, fashion photography, studio lighting",
    spicy: "provocative, confident, alluring, professional lighting",
    adult: "artistic, tasteful, professional photography, studio lighting",
  };

  return `${basePrompt}, ${styleModifiers[contentType]}, ${qualityModifiers}`;
}

/**
 * Testar conexão com Hugging Face
 */
export async function testHuggingFaceConnection(): Promise<boolean> {
  try {
    if (!HF_API_KEY) {
      console.error("HUGGING_FACE_API_KEY não configurada");
      return false;
    }

    const response = await fetch(`${HF_API_URL}/${MODELS.STABLE_DIFFUSION_2}`, {
      headers: {
        Authorization: `Bearer ${HF_API_KEY}`,
      },
      method: "POST",
      body: JSON.stringify({
        inputs: "test",
      }),
    });

    console.log("Teste de conexão Hugging Face:", response.status);
    return response.ok || response.status === 503; // 503 = modelo carregando
  } catch (error) {
    console.error("Erro ao testar Hugging Face:", error);
    return false;
  }
}

