  const result = await db
    .select()
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .orderBy(subscriptions.createdAt)
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

export async function createSubscription(data: {
  userId: number;
  paypalSubscriptionId?: string;
  status: "active" | "cancelled" | "expired" | "pending";
  currency: "BRL" | "USD" | "EUR";
  amount: number;
  startDate?: Date;
  endDate?: Date;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const { subscriptions } = await import("../drizzle/schema");
  const result = await db.insert(subscriptions).values(data);
  return result;
}

export async function updateSubscription(
  id: number,
  data: Partial<{
    paypalSubscriptionId: string;
    status: "active" | "cancelled" | "expired" | "pending";
    endDate: Date;
  }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const { subscriptions } = await import("../drizzle/schema");
  await db.update(subscriptions).set(data).where(eq(subscriptions.id, id));
}

// ============================================
// CHARACTER QUERIES
// ============================================

export async function getUserCharacters(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const { characters } = await import("../drizzle/schema");
  return await db
    .select()
    .from(characters)
    .where(eq(characters.userId, userId))
    .orderBy(characters.createdAt);
}

export async function getCharacterById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const { characters } = await import("../drizzle/schema");
  const result = await db
    .select()
    .from(characters)
    .where(eq(characters.id, id))
    .limit(1);
  
  if (result.length === 0) return undefined;
  if (result[0].userId !== userId) return undefined;
  
  return result[0];
}

export async function createCharacter(data: {
  userId: number;
  name: string;
  ethnicity?: string;
  hairColor?: string;
  hairStyle?: string;
  eyeColor?: string;
  faceShape?: string;
  bodyType?: string;
  mainOutfit?: string;
  accessories?: string;
  colorPalette?: string;
  scenario?: string;
  archetype?: string;
  voiceTone?: string;
  interests?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const { characters } = await import("../drizzle/schema");
  const result = await db.insert(characters).values(data);
  return result;
}
