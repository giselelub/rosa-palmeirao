import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Image as ImageIcon, Video, MessageCircle, Sparkles } from "lucide-react";

interface Character {
  id: number;
  name: string;
  contentRating: "glamour" | "spicy" | "adult";
  imageStyle: "realistic" | "anime";
}

export default function DashboardCharacterCard({ character }: { character: Character }) {
  const contentRatingLabel = {
    glamour: "🌸 Glamour",
    spicy: "🌶️ Spicy",
    adult: "🔞 Adult",
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle>{character.name}</CardTitle>
            <CardDescription>
              {contentRatingLabel[character.contentRating]}
            </CardDescription>
          </div>
          <Sparkles className="h-5 w-5 text-pink-500" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Quick Action Buttons */}
        <div className="grid grid-cols-3 gap-2">
          <Link href={`/generate-image/${character.id}`}>
            <Button
              size="sm"
              variant="outline"
              className="w-full"
              title="Gerar Imagem"
            >
              <ImageIcon className="h-4 w-4" />
            </Button>
          </Link>

          <Link href={`/generate-dance/${character.id}`}>
            <Button
              size="sm"
              variant="outline"
              className="w-full"
              title="Gerar Vídeo"
            >
              <Video className="h-4 w-4" />
            </Button>
          </Link>

          <Link href={`/chat/${character.id}`}>
            <Button
              size="sm"
              variant="outline"
              className="w-full"
              title="Chat"
            >
              <MessageCircle className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        {/* View Details Button */}
        <Link href={`/generate/${character.id}/image`}>
          <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
            Ver Detalhes
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

