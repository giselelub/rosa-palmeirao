import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { contactRouter } from "./contactRouter";
import { subscriptionRouter } from "./subscriptionRouter";
import { characterRouter } from "./characterRouter";
import { paypalRouter } from "./paypalRouter";
import { generationRouter } from "./generationRouter";
import { stripeRouter } from "./stripeRouter";
import { authEmailRouter } from "./authEmailRouter";
import { adCreativeRouter } from "./adCreativeRouter";
import { characterSaveRouter } from "./characterSaveRouter";
import { contentGenerationRouter } from "./contentGenerationRouter";
import { subscriptionLimitRouter } from "./subscriptionLimitRouter";

export const appRouter = router({
  system: systemRouter,
  contact: contactRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    email: authEmailRouter,
  }),

  subscription: subscriptionRouter,
  character: router({
    ...characterRouter.router,
    save: characterSaveRouter,
  }),
  paypal: paypalRouter,
  generation: generationRouter,
  stripe: stripeRouter,
  adCreative: adCreativeRouter,
  contentGeneration: contentGenerationRouter,
  subscriptionLimit: subscriptionLimitRouter,
});

export type AppRouter = typeof appRouter;
