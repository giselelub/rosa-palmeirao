# 🚀 Passo a Passo - Criar Banco de Dados e Deploy na Vercel

Vou guiar você passo a passo para colocar seu app online!

---

## 📋 Passo 1: Criar Banco de Dados (5 minutos)

### 1.1 Abrir Vercel

1. Abra seu navegador
2. Cole este link: **https://vercel.com/dashboard**
3. Você deve estar logado (se não estiver, faça login)

### 1.2 Ir para Storage

1. Procure no menu esquerdo por: **"Storage"**
2. Clique em "Storage"

### 1.3 Criar Banco de Dados

1. Clique em **"Create Database"** (botão grande)
2. Você vai ver opções de banco de dados
3. Procure por: **"Vercel Postgres"**
4. Clique em **"Vercel Postgres"**

### 1.4 Configurar Banco de Dados

1. Preencha os dados:
   - **Database Name:** `rosa_palmeirao` (ou outro nome)
   - **Region:** Escolha **"São Paulo (sao1)"**
   - **Billing Plan:** Deixe como está (gratuito)

2. Clique em **"Create"**

3. Aguarde alguns segundos (vai criar o banco)

### 1.5 Copiar Connection String

1. Quando terminar, clique na aba **"Postgres"**
2. Você vai ver um código grande (connection string)
3. Procure por um botão **".env.local"**
4. Clique nele
5. Você vai ver algo como:
   ```
   POSTGRES_PRISMA_URL=postgresql://user:password@host/database
   POSTGRES_URL_NON_POOLING=postgresql://user:password@host/database
   ```

6. **Copie a primeira linha** (POSTGRES_PRISMA_URL)
7. **Guarde em um lugar seguro** (você vai precisar)

---

## 🌐 Passo 2: Fazer Deploy na Vercel (10 minutos)

### 2.1 Ir para Novo Projeto

1. Abra: **https://vercel.com/dashboard**
2. Clique em **"Add New..."** (canto superior esquerdo)
3. Selecione **"Project"**

### 2.2 Importar Repositório

1. Você vai ver uma página com opções
2. Procure por: **"Import Git Repository"**
3. Cole este link: `https://github.com/giselelub/rosa-palmeirao`
4. Clique em **"Import"**

### 2.3 Configurar Projeto

1. Você vai para uma página de configuração
2. Preencha:
   - **Project Name:** `rosa-palmeirao`
   - **Framework Preset:** Deixe como está

### 2.4 Adicionar Variáveis de Ambiente

1. Procure por: **"Environment Variables"**
2. Clique em **"Add New"** para adicionar variáveis

3. **Adicione estas variáveis:**

   **Variável 1:**
   - Name: `DATABASE_URL`
   - Value: (Cole a connection string que você copiou)
   - Clique em "Add"

   **Variável 2:**
   - Name: `HUGGING_FACE_API_KEY`
   - Value: `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`
   - Clique em "Add"

   **Variável 3:**
   - Name: `VITE_APP_TITLE`
   - Value: `Rosa Palmeirão`
   - Clique em "Add"

   **Variável 4:**
   - Name: `NODE_ENV`
   - Value: `production`
   - Clique in "Add"

### 2.5 Fazer Deploy

1. Clique em **"Deploy"** (botão grande no final)
2. Aguarde 3-5 minutos
3. Você vai ver uma tela de "Building..."
4. Quando terminar, você vai receber um link como:
   ```
   https://rosa-palmeirao.vercel.app
   ```

---

## ✅ Passo 3: Testar o App (5 minutos)

### 3.1 Acessar o App

1. Clique no link que você recebeu
2. Você deve ver a página inicial do Rosa Palmeirão

### 3.2 Fazer Cadastro

1. Clique em **"Cadastre-se"**
2. Preencha:
   - Email: `giselelubanco2@gmail.com`
   - Senha: Crie uma senha forte
   - Confirmar Senha: Digite a mesma senha
3. Clique em **"Cadastrar"**

### 3.3 Fazer Login

1. Clique em **"Entrar"**
2. Use o email e senha que cadastrou
3. Você deve ver o **Dashboard**

### 3.4 Testar Geração de Imagem

1. Clique em **"Criar Novo Personagem"**
2. Preencha os dados (pode ser fictício):
   - Nome: `Luna`
   - Categoria: `Spicy`
   - Continue nos próximos passos
3. Clique em **"Salvar Personagem"**
4. Clique no ícone de câmera (📷)
5. Clique em **"Gerar Imagem"**
6. Aguarde 30-60 segundos
7. Você deve ver uma imagem gerada!

---

## 🎉 Pronto!

Seu app está online! 🚀

**Link:** `https://rosa-palmeirao.vercel.app`

---

## 📊 Resumo do que você fez:

| Passo | Tempo | O que fez |
|-------|-------|----------|
| 1 | 5 min | Criar banco de dados Postgres |
| 2 | 10 min | Fazer deploy na Vercel |
| 3 | 5 min | Testar o app |
| **Total** | **20 min** | **App online!** |

---

## 🆘 Se Tiver Problemas

### "Não encontro Storage"
- Verifique se está logado na Vercel
- Tente atualizar a página (F5)

### "Não encontro Create Database"
- Clique em "Storage" no menu esquerdo
- Procure por um botão "Create" ou "New Database"

### "Erro ao fazer deploy"
- Verifique se todas as variáveis estão corretas
- Tente fazer novo deploy

### "Imagem não gera"
- Aguarde 30-60 segundos
- Tente novamente
- Verifique se o token do Hugging Face está correto

---

## 💡 Dicas

1. **Salve o link do seu app:** `https://rosa-palmeirao.vercel.app`
2. **Compartilhe com amigos:** Eles podem testar
3. **Configure as assinaturas:** Para começar a ganhar
4. **Customize o design:** Mude cores, logo, etc

---

**Boa sorte! 💪 Você consegue!**

Se tiver dúvida em qualquer passo, me avisa!

