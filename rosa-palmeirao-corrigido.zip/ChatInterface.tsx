import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, Send, AlertCircle, Loader, Download } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

const CONVERSATION_TYPES = {
  normal: { label: "💬 Conversação Normal", desc: "Conversa amigável e educada" },
  spicy: { label: "🌶️ Conversação Picante", desc: "Conversa ousada e provocante" },
};

const PRESET_MESSAGES = {
  normal: [
    "Oi, tudo bem?",
    "Como você está?",
    "Qual é seu maior sonho?",
    "Você acredita em destino?",
    "Qual é seu interesse favorito?",
  ],
  spicy: [
    "Você é muito atraente",
    "Gostaria de conhecer você melhor",
    "Qual é seu tipo ideal?",
    "Você gosta de se divertir?",
    "Quer conversar mais?",
  ],
};

export default function ChatInterface() {
  const { t } = useTranslation();
  const [match, params] = useRoute("/chat/:characterId");

  const characterId = params?.characterId ? parseInt(params.characterId) : null;

  const [conversationType, setConversationType] = useState<"normal" | "spicy">("normal");
  const [messages, setMessages] = useState<Array<{ role: "user" | "character"; text: string }>>([]);
  const [inputMessage, setInputMessage] = useState("");

  // Buscar personagem
  const { data: character } = trpc.character.save.getById.useQuery(
    { id: characterId || 0 },
    { enabled: !!characterId }
  );

  // Gerar resposta
  const generateChatMutation = trpc.contentGeneration.generateChat.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setMessages((prev) => [...prev, { role: "character", text: data.response }]);
      }
    },
    onError: (error) => {
      alert(error.message || "Erro ao gerar resposta");
    },
  });

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !characterId) return;

    // Adicionar mensagem do usuário
    setMessages((prev) => [...prev, { role: "user", text: inputMessage }]);
    setInputMessage("");

    // Gerar resposta
    await generateChatMutation.mutateAsync({
      characterId,
      message: inputMessage,
    });
  };

  const handlePresetMessage = async (message: string) => {
    if (!characterId) return;

    // Adicionar mensagem do usuário
    setMessages((prev) => [...prev, { role: "user", text: message }]);

    // Gerar resposta
    await generateChatMutation.mutateAsync({
      characterId,
      message,
    });
  };

  const handleDownloadChat = () => {
    const chatText = messages
      .map((m) => `${m.role === "user" ? "Você" : character?.name}: ${m.text}`)
      .join("\n\n");

    const element = document.createElement("a");
    element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(chatText));
    element.setAttribute("download", `chat_${character?.name}_${Date.now()}.txt`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  if (!characterId) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900 flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">Personagem não encontrado</p>
            <Link href="/dashboard">
              <Button className="w-full mt-4">Voltar ao Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
        </div>
      </header>

      <div className="container py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Conversar com {character?.name}</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Escolha o tipo de conversa e comece a interagir
          </p>
        </div>

        {/* Conversation Type Selector */}
        <div className="mb-8 grid grid-cols-2 gap-4">
          {Object.entries(CONVERSATION_TYPES).map(([key, { label, desc }]) => (
            <label
              key={key}
              className={`flex items-center p-4 border rounded-lg cursor-pointer transition ${
                conversationType === key
                  ? "border-pink-500 bg-pink-50 dark:bg-pink-900/20"
                  : "border-gray-200 dark:border-gray-700 hover:border-pink-300"
              }`}
            >
              <input
                type="radio"
                name="conversationType"
                value={key}
                checked={conversationType === key}
                onChange={(e) => setConversationType(e.target.value as any)}
                className="mr-3"
              />
              <div>
                <div className="font-medium">{label}</div>
                <div className="text-xs text-gray-500">{desc}</div>
              </div>
            </label>
          ))}
        </div>

        {/* Chat Container */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Conversa</CardTitle>
            <CardDescription>
              {CONVERSATION_TYPES[conversationType].label}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Messages Display */}
            <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 h-96 overflow-y-auto space-y-4">
              {messages.length === 0 ? (
                <div className="h-full flex items-center justify-center text-center">
                  <p className="text-gray-500 dark:text-gray-400">
                    Nenhuma mensagem ainda. Comece a conversa!
                  </p>
                </div>
              ) : (
                messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xs px-4 py-2 rounded-lg ${
                        msg.role === "user"
                          ? "bg-pink-500 text-white rounded-br-none"
                          : "bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white rounded-bl-none"
                      }`}
                    >
                      <p className="text-sm">{msg.text}</p>
                    </div>
                  </div>
                ))
              )}
              {generateChatMutation.isPending && (
                <div className="flex justify-start">
                  <div className="bg-gray-200 dark:bg-gray-700 px-4 py-2 rounded-lg rounded-bl-none">
                    <Loader className="h-4 w-4 animate-spin" />
                  </div>
                </div>
              )}
            </div>

            {/* Preset Messages */}
            <div>
              <p className="text-sm font-medium mb-2">Mensagens Rápidas:</p>
              <div className="grid grid-cols-2 gap-2">
                {PRESET_MESSAGES[conversationType].map((msg, idx) => (
                  <Button
                    key={idx}
                    variant="outline"
                    size="sm"
                    onClick={() => handlePresetMessage(msg)}
                    disabled={generateChatMutation.isPending}
                    className="text-xs"
                  >
                    {msg}
                  </Button>
                ))}
              </div>
            </div>

            {/* Message Input */}
            <div className="flex gap-2">
              <Input
                placeholder="Digite sua mensagem..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !generateChatMutation.isPending) {
                    handleSendMessage();
                  }
                }}
                disabled={generateChatMutation.isPending}
              />
              <Button
                onClick={handleSendMessage}
                disabled={generateChatMutation.isPending || !inputMessage.trim()}
                className="bg-gradient-to-r from-pink-500 to-purple-600"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>

            {/* Download Button */}
            {messages.length > 0 && (
              <Button
                variant="outline"
                className="w-full"
                onClick={handleDownloadChat}
              >
                <Download className="h-4 w-4 mr-2" />
                Baixar Conversa
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Info Box */}
        {conversationType === "spicy" && (
          <Card className="border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-900/20">
            <CardContent className="pt-6 flex items-start gap-2">
              <AlertCircle className="h-5 w-5 text-orange-600 dark:text-orange-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm text-orange-700 dark:text-orange-300">
                  <strong>Conversação Picante:</strong> Este modo permite conversas mais ousadas e provocantes. Apenas para maiores de idade.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

