# ✅ Checklist Pré-Deploy

Use este checklist para garantir que tudo está configurado corretamente antes de fazer o deploy.

---

## 🔧 Configuração Local

- [ ] Node.js 18+ instalado (`node --version`)
- [ ] npm 9+ instalado (`npm --version`)
- [ ] Repositório Git inicializado (`git status`)
- [ ] Arquivo `.env` criado com todas as variáveis
- [ ] Dependências instaladas (`npm install`)
- [ ] Sem erros de build (`npm run build`)
- [ ] Sem erros de type-check (`npm run type-check`)

---

## 📦 Banco de Dados

- [ ] Conta Neon criada em [console.neon.tech](https://console.neon.tech)
- [ ] Projeto criado no Neon
- [ ] String de conexão obtida
- [ ] String de conexão adicionada ao `.env` local
- [ ] Migrações geradas (`npm run db:generate`)
- [ ] Migrações executadas localmente (`npm run db:push`)
- [ ] Tabelas criadas com sucesso no Neon

---

## 🌐 GitHub

- [ ] Repositório GitHub criado
- [ ] Código feito push para GitHub (`git push origin main`)
- [ ] Todos os arquivos importantes estão no repositório
- [ ] Arquivo `.env` NÃO está no repositório (adicione ao `.gitignore`)
- [ ] Arquivo `.gitignore` contém: `.env`, `node_modules/`, `dist/`, etc.

---

## 🚀 Frontend (Vercel)

- [ ] Conta Vercel criada em [vercel.com](https://vercel.com)
- [ ] Repositório GitHub conectado ao Vercel
- [ ] Variáveis de ambiente configuradas:
  - [ ] `VITE_API_URL` = URL do backend Render (será obtida após deploy)
  - [ ] `VITE_APP_TITLE` = "Rosa Palmeirão"
- [ ] Build command correto: `npm run build`
- [ ] Output directory correto: `dist`
- [ ] Deploy realizado com sucesso
- [ ] URL do Vercel obtida (ex: `https://rosa-palmeirao.vercel.app`)

---

## ⚙️ Backend (Render)

- [ ] Conta Render criada em [render.com](https://render.com)
- [ ] Repositório GitHub conectado ao Render
- [ ] Build command: `npm install && npm run build`
- [ ] Start command: `npm start`
- [ ] Variáveis de ambiente configuradas:
  - [ ] `DATABASE_URL` = String de conexão do Neon
  - [ ] `NODE_ENV` = "production"
  - [ ] `SERVER_PORT` = "5000"
  - [ ] `SESSION_SECRET` = Chave segura gerada
  - [ ] `OPENAI_API_KEY` = Sua chave OpenAI
  - [ ] `HUGGING_FACE_API_KEY` = Sua chave Hugging Face
  - [ ] `CLOUDINARY_CLOUD_NAME` = Seu cloud name
  - [ ] `CLOUDINARY_API_KEY` = Sua chave API
  - [ ] `CLOUDINARY_API_SECRET` = Seu secret
  - [ ] `RESEND_API_KEY` = Sua chave Resend
  - [ ] `PAYPAL_CLIENT_ID` = Seu client ID
  - [ ] `PAYPAL_CLIENT_SECRET` = Seu client secret
  - [ ] `PAYPAL_MODE` = "sandbox" (ou "live" se pronto para produção)
  - [ ] `VITE_API_URL` = URL do Render (será obtida após deploy)
- [ ] Deploy realizado com sucesso
- [ ] URL do Render obtida (ex: `https://rosa-palmeirao-backend.onrender.com`)

---

## 🔑 Chaves de API

- [ ] **Hugging Face:** Chave obtida em [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens)
- [ ] **OpenAI:** Chave obtida em [platform.openai.com/api-keys](https://platform.openai.com/api-keys)
- [ ] **Cloudinary:** Credenciais obtidas em [cloudinary.com/console](https://cloudinary.com/console)
- [ ] **Resend:** Chave obtida em [resend.com/api-keys](https://resend.com/api-keys)
- [ ] **PayPal:** Credenciais obtidas em [developer.paypal.com](https://developer.paypal.com)
- [ ] Todas as chaves adicionadas ao Render (não ao Vercel, pois é frontend)

---

## 🧪 Testes Pré-Deploy

- [ ] Aplicativo roda localmente sem erros (`npm run dev`)
- [ ] Frontend acessível em `http://localhost:5173`
- [ ] Backend acessível em `http://localhost:5000`
- [ ] Banco de dados conecta com sucesso
- [ ] Página de login carrega
- [ ] Pode criar conta (teste com email fake)
- [ ] Pode fazer login
- [ ] Dashboard carrega
- [ ] Pode criar personagem
- [ ] Pode gerar imagem (se chave Hugging Face está configurada)
- [ ] Chat funciona (se chave OpenAI está configurada)

---

## 🚀 Deploy em Produção

- [ ] Vercel deploy concluído com sucesso
- [ ] Render deploy concluído com sucesso
- [ ] URLs obtidas:
  - [ ] Frontend: `https://rosa-palmeirao.vercel.app`
  - [ ] Backend: `https://rosa-palmeirao-backend.onrender.com`
- [ ] Variável `VITE_API_URL` do Vercel atualizada com URL do Render
- [ ] Vercel redeploy realizado após atualizar `VITE_API_URL`

---

## ✅ Testes Pós-Deploy

- [ ] Frontend acessível em `https://rosa-palmeirao.vercel.app`
- [ ] Página de login carrega
- [ ] Pode criar conta
- [ ] Pode fazer login
- [ ] Dashboard carrega
- [ ] Pode criar personagem
- [ ] Pode gerar imagem
- [ ] Chat funciona
- [ ] Sem erros no console do navegador
- [ ] Sem erros nos logs do Render

---

## 📊 Monitoramento

- [ ] Verificar logs do Vercel regularmente
- [ ] Verificar logs do Render regularmente
- [ ] Monitorar uso de storage do Neon
- [ ] Monitorar uso de horas do Render (750 horas/mês)
- [ ] Monitorar uso de bandwidth do Vercel
- [ ] Monitorar uso de tokens do OpenAI

---

## 🎉 Pronto para Lançar!

Se todos os itens acima estão marcados, seu aplicativo está pronto para o lançamento público! 🚀

---

## 📝 Notas

- Salve este checklist e use-o para futuras atualizações
- Mantenha as chaves de API seguras e nunca as compartilhe
- Faça backup regular do seu banco de dados
- Monitore o uso dos serviços gratuitos para evitar surpresas

---

**Boa sorte com o lançamento do Rosa Palmeirão! 🎬**

