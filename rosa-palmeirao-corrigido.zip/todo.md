
## Banco de Dados
- [x] Criar tabela de assinaturas (subscriptions)
- [x] Criar tabela de personagens customizados (characters)
- [x] Criar tabela de histórico de gerações (generations)
- [x] Criar tabela de transações PayPal (transactions)

## Backend - Sistema de Assinaturas
- [x] Endpoint para verificar status de assinatura do usuário
- [x] Endpoint para criar nova assinatura
- [x] Endpoint para cancelar assinatura
- [x] Middleware de verificação de assinatura ativa

## Backend - Integração PayPal
- [x] Configurar credenciais PayPal (sandbox mode)
- [x] Endpoint para criar plano de assinatura PayPal
- [x] Endpoint para processar aprovação de assinatura
- [x] Webhook para receber notificações de pagamento do PayPal
- [x] Webhook para receber notificações de cancelamento
- [x] Suporte para múltiplas moedas (BRL, USD, EUR)

## Backend - Geração de Conteúdo
- [x] Endpoint para criar/editar personagem customizado
- [x] Endpoint para gerar imagem estática (usando prompt detalhado)
- [x] Endpoint para gerar animação de dança (9 segundos)
- [x] Endpoint para gerar diálogos/conversação baseado em personalidade
- [x] Endpoint para listar personagens do usuário
- [x] Endpoint para listar histórico de gerações

## Frontend - Landing Page
- [x] Seção hero com apresentação do serviço
- [x] Seção de funcionalidades (imagem, animação, chat)
- [x] Seção de preços (R$ 80/mês com múltiplas moedas)
- [x] Botão de login/cadastro
- [x] Footer com links úteis

## Frontend - Dashboard do Usuário
- [x] Página de status de assinatura
- [x] Botão para assinar/gerenciar assinatura
- [x] Lista de personagens criados
- [x] Botão para criar novo personagem

## Frontend - Criador de Personagem
- [ ] Formulário de customização física (etnia, cabelo, olhos, corpo)
- [ ] Formulário de customização de estilo (vestimenta, acessórios, cenário)
- [ ] Formulário de customização de personalidade (arquétipo, tom, interesses)
- [ ] Preview da configuração
- [ ] Botão para salvar personagem

## Frontend - Visualizador de Conteúdo
- [ ] Página para visualizar imagem gerada
- [ ] Player de vídeo para animação de dança
- [ ] Interface de chat com diálogos prontos
- [ ] Botão para gerar novo conteúdo
- [ ] Histórico de gerações anteriores

## Internacionalização (i18n)
- [x] Configurar biblioteca de i18n (react-i18next)
- [x] Tradução para Português (PT)
- [x] Tradução para Inglês (EN)
- [x] Tradução para Espanhol (ES)
- [x] Seletor de idioma no header

## Testes e Documentação
- [ ] Testar fluxo completo de assinatura PayPal
- [ ] Testar geração de conteúdo
- [ ] Testar troca de idiomas
- [ ] Documentar configuração de credenciais PayPal
- [ ] Criar checkpoint final




## Backend - Integração Stripe
- [ ] Configurar credenciais Stripe
- [ ] Endpoint para criar checkout session Stripe
- [ ] Endpoint para criar portal de gerenciamento de assinatura
- [ ] Webhook para receber eventos Stripe
- [ ] Suporte para múltiplas moedas (BRL, USD, EUR)

## Frontend - Opção de Pagamento Stripe
- [ ] Adicionar botão de pagamento via Stripe
- [ ] Página de sucesso após pagamento
- [ ] Página de cancelamento




## Backend - Integração Stripe (Alternativa ao PayPal)
- [x] Configurar credenciais Stripe
- [x] Endpoint para criar checkout session Stripe
- [x] Endpoint para criar portal de gerenciamento de assinatura
- [x] Webhook para receber eventos Stripe
- [x] Suporte para múltiplas moedas (BRL, USD, EUR)

## Frontend - Opção de Pagamento Stripe
- [x] Adicionar botão de pagamento via Stripe
- [x] Página de sucesso após pagamento
- [x] Página de cancelamento




## Sistema de Categorias de Conteúdo
- [x] Adicionar campo 'contentRating' ao schema de personagens (glamour, spicy, adult)
- [x] Modal de verificação de idade +18
- [ ] Seletor de categoria ao criar/editar personagem (frontend)
- [x] Ícones visuais para categorias (🌸 🌶️ 🔞)
- [x] Ajustar prompts de geração baseado na categoria
- [x] Conversação mais ousada para categoria 'spicy' e 'adult'
- [x] Avisos e disclaimers apropriados




## Página de Demonstração
- [x] Criar página /demo com showcase completo
- [x] Seção de exemplos de personagens
- [x] Galeria de imagens geradas
- [x] Comparação de custos (tradicional vs Rosa Palmeirão)
- [x] Depoimentos de usuários
- [x] FAQ expandido




## Formulário de Contato
- [x] Criar endpoint backend para receber mensagens de contato
- [x] Notificar proprietário quando receber mensagem
- [x] Adicionar formulário de contato na página /demo
- [x] Validação de campos
- [x] Feedback visual de sucesso/erro




## Reestruturação de Planos e Funcionalidades
- [x] Criar 4 planos de assinatura (Básico R$ 49,90, Premium R$ 80, VIP R$ 130, Rosa Palmeirão R$ 200)
- [x] Implementar limites diários por plano (20, 70, 150, ilimitado)
- [x] Atualizar schema do banco com novos campos
- [x] Criar helpers de verificação de limites
- [x] Atualizar prompts para conteúdo +18 (nu, poses diversas)
- [x] Implementar contador de uso diário
- [x] Atualizar generationRouter com verificações
- [x] Atualizar página de preços com novos planos (frontend)
- [ ] Mostrar limites restantes no dashboard (frontend)
- [ ] Atualizar subscriptionRouter para novos planos
- [x] Criar rota /pricing
- [x] Atualizar landing page para linkar para pricing

