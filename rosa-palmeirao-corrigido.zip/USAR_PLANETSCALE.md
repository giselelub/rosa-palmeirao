# 🚀 Usar PlanetScale (MySQL Gratuito) - Rosa Palmeirão

Seu projeto usa **MySQL**, então vamos usar **PlanetScale** em vez de Vercel Postgres!

PlanetScale oferece MySQL gratuito e é perfeito para seu app.

---

## 📋 Passo 1: Criar Conta PlanetScale (5 minutos)

### 1.1 Abrir PlanetScale

1. Abra este link: **https://app.planetscale.com/register**
2. Clique em **"Sign up"**

### 1.2 Criar Conta

1. Preencha com seus dados:
   - Email: `giselelubanco2@gmail.com`
   - Password: Crie uma senha forte
2. Clique em **"Create account"**
3. Confirme seu email (abra o email e clique no link)

### 1.3 Criar Banco de Dados

1. Faça login em: **https://app.planetscale.com**
2. Clique em **"Create a database"** ou **"New database"**
3. Preencha:
   - **Database name:** `rosa_palmeirao`
   - **Region:** Escolha **"São Paulo"** (se disponível) ou **"us-east"**
   - **Plan:** Deixe como **"Free"** (gratuito)
4. Clique em **"Create database"**
5. Aguarde alguns segundos

### 1.4 Copiar Connection String

1. Quando o banco for criado, você vai ver uma página com opções
2. Procure por um botão **"Connect"** ou **".env"**
3. Clique em **".env"** ou **"Connection string"**
4. Você vai ver algo como:
   ```
   DATABASE_URL="mysql://user:password@host/database"
   ```
5. **Copie a string completa**
6. **Guarde em um lugar seguro**

---

## 🌐 Passo 2: Fazer Deploy na Vercel (10 minutos)

### 2.1 Ir para Novo Projeto

1. Abra: **https://vercel.com/new**
2. Clique em **"Import Git Repository"**

### 2.2 Importar Repositório

1. Cole este link: `https://github.com/giselelub/rosa-palmeirao`
2. Clique em **"Import"**

### 2.3 Configurar Projeto

1. Preencha:
   - **Project Name:** `rosa-palmeirao`
   - **Framework:** Deixe como está

### 2.4 Adicionar Variáveis de Ambiente

1. Procure por: **"Environment Variables"**
2. Clique em **"Add New"** para adicionar cada variável

3. **Adicione estas variáveis:**

   **Variável 1:**
   - Name: `DATABASE_URL`
   - Value: (Cole a connection string do PlanetScale)
   - Clique em "Add"

   **Variável 2:**
   - Name: `HUGGING_FACE_API_KEY`
   - Value: `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`
   - Clique em "Add"

   **Variável 3:**
   - Name: `VITE_APP_TITLE`
   - Value: `Rosa Palmeirão`
   - Clique em "Add"

   **Variável 4:**
   - Name: `NODE_ENV`
   - Value: `production`
   - Clique em "Add"

### 2.5 Fazer Deploy

1. Clique em **"Deploy"** (botão grande)
2. Aguarde 3-5 minutos
3. Quando terminar, você receberá um link:
   ```
   https://rosa-palmeirao.vercel.app
   ```

---

## ✅ Passo 3: Testar o App (5 minutos)

### 3.1 Acessar o App

1. Clique no link que você recebeu
2. Você deve ver a página inicial do Rosa Palmeirão

### 3.2 Fazer Cadastro

1. Clique em **"Cadastre-se"**
2. Preencha:
   - Email: `giselelubanco2@gmail.com`
   - Senha: Crie uma senha
   - Confirmar: Digite a mesma senha
3. Clique em **"Cadastrar"**

### 3.3 Fazer Login

1. Clique em **"Entrar"**
2. Use o email e senha que cadastrou
3. Você deve ver o **Dashboard**

### 3.4 Testar Geração

1. Clique em **"Criar Novo Personagem"**
2. Preencha os dados
3. Clique em **"Salvar"**
4. Clique no ícone de câmera
5. Clique em **"Gerar Imagem"**
6. Aguarde 30-60 segundos
7. Você deve ver uma imagem gerada!

---

## 🎉 Pronto!

Seu app está online! 🚀

**Link:** `https://rosa-palmeirao.vercel.app`

---

## 📊 Resumo:

| Passo | Tempo | O que fez |
|-------|-------|----------|
| 1 | 5 min | Criar banco PlanetScale |
| 2 | 10 min | Fazer deploy Vercel |
| 3 | 5 min | Testar app |
| **Total** | **20 min** | **App online!** |

---

## 💰 Custos:

- ✅ PlanetScale: **GRATUITO**
- ✅ Vercel: **GRATUITO**
- ✅ Hugging Face: **GRATUITO**
- ✅ **Total: R$ 0,00** 🎉

---

## 🆘 Se Tiver Problemas

### "Não consigo copiar a connection string"
- Procure por um botão "Copy" ou "Show password"
- Clique nele
- A string vai aparecer

### "Erro ao fazer deploy"
- Verifique se a DATABASE_URL está correta
- Tente fazer novo deploy

### "Imagem não gera"
- Aguarde 30-60 segundos
- Tente novamente
- Verifique o token do Hugging Face

---

**Boa sorte! 💪 Você consegue!**

