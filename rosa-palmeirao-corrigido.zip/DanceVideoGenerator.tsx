import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, Download, Share2, AlertCircle, Loader, Video } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

const VIDEO_SIZES = {
  hd: { label: "HD (720x1280)", value: "720x1280" },
  fullhd: { label: "Full HD (1080x1920)", value: "1080x1920" },
  "2k": { label: "2K (1440x2560)", value: "1440x2560" },
};

const CONTENT_TYPES = {
  glamour: { label: "🌸 Glamour", desc: "Dança elegante e sofisticada" },
  spicy: { label: "🌶️ Spicy", desc: "Dança ousada e provocante" },
  adult: { label: "🔞 Adult +18", desc: "Dança adulta sem censura" },
};

export default function DanceVideoGenerator() {
  const { t } = useTranslation();
  const [match, params] = useRoute("/generate-dance/:characterId");

  const characterId = params?.characterId ? parseInt(params.characterId) : null;

  const [size, setSize] = useState<keyof typeof VIDEO_SIZES>("fullhd");
  const [contentType, setContentType] = useState<"glamour" | "spicy" | "adult">("glamour");
  const [musicName, setMusicName] = useState("");
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);

  // Buscar personagem
  const { data: character } = trpc.character.save.getById.useQuery(
    { id: characterId || 0 },
    { enabled: !!characterId }
  );

  // Gerar vídeo
  const generateDanceMutation = trpc.contentGeneration.generateDance.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setGeneratedVideo(data.videoUrl);
      }
    },
    onError: (error) => {
      alert(error.message || "Erro ao gerar vídeo");
    },
  });

  const handleGenerateVideo = async () => {
    if (!characterId) return;
    if (!musicName.trim()) {
      alert("Por favor, digite o nome da música");
      return;
    }

    await generateDanceMutation.mutateAsync({
      characterId,
      musicName,
      contentType,
    });
  };

  const handleDownload = async () => {
    if (!generatedVideo) return;

    setDownloading(true);
    try {
      const response = await fetch(generatedVideo);
      const blob = await response.blob();
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `danca_${character?.name}_${Date.now()}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert("Erro ao baixar vídeo");
    } finally {
      setDownloading(false);
    }
  };

  const handleShare = () => {
    if (!generatedVideo) return;

    if (navigator.share) {
      navigator.share({
        title: `Confira a dança de ${character?.name}!`,
        url: generatedVideo,
      });
    } else {
      navigator.clipboard.writeText(generatedVideo);
      alert("Link copiado para a área de transferência!");
    }
  };

  if (!characterId) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900 flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">Personagem não encontrado</p>
            <Link href="/dashboard">
              <Button className="w-full mt-4">Voltar ao Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
        </div>
      </header>

      <div className="container py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Gerar Vídeo de Dança</h1>
          <p className="text-gray-600 dark:text-gray-400">
            {character?.name} - Crie vídeos de dança personalizados
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Configuration Panel */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Configurações</CardTitle>
                <CardDescription>Personalize seu vídeo</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Music Input */}
                <div>
                  <label className="block text-sm font-medium mb-2">Nome da Música *</label>
                  <Input
                    placeholder="Ex: Blinding Lights - The Weeknd"
                    value={musicName}
                    onChange={(e) => setMusicName(e.target.value)}
                    disabled={generateDanceMutation.isPending}
                  />
                </div>

                {/* Content Type Selection */}
                <div>
                  <label className="block text-sm font-medium mb-3">Tipo de Conteúdo</label>
                  <div className="space-y-2">
                    {Object.entries(CONTENT_TYPES).map(([key, { label, desc }]) => (
                      <label
                        key={key}
                        className={`flex items-center p-3 border rounded-lg cursor-pointer transition ${
                          contentType === key
                            ? "border-pink-500 bg-pink-50 dark:bg-pink-900/20"
                            : "border-gray-200 dark:border-gray-700 hover:border-pink-300"
                        }`}
                      >
                        <input
                          type="radio"
                          name="contentType"
                          value={key}
                          checked={contentType === key}
                          onChange={(e) => setContentType(e.target.value as any)}
                          className="mr-3"
                          disabled={generateDanceMutation.isPending}
                        />
                        <div>
                          <div className="font-medium">{label}</div>
                          <div className="text-xs text-gray-500">{desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>

                  {contentType === "adult" && (
                    <div className="mt-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded text-sm text-red-700 dark:text-red-300 flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                      <span>Conteúdo +18 - Apenas para maiores de idade</span>
                    </div>
                  )}
                </div>

                {/* Size Selection */}
                <div>
                  <label className="block text-sm font-medium mb-3">Qualidade do Vídeo</label>
                  <div className="space-y-2">
                    {Object.entries(VIDEO_SIZES).map(([key, { label, value }]) => (
                      <label
                        key={key}
                        className={`flex items-center p-2 border rounded cursor-pointer transition ${
                          size === key
                            ? "border-pink-500 bg-pink-50 dark:bg-pink-900/20"
                            : "border-gray-200 dark:border-gray-700 hover:border-pink-300"
                        }`}
                      >
                        <input
                          type="radio"
                          name="size"
                          value={key}
                          checked={size === key}
                          onChange={(e) => setSize(e.target.value as any)}
                          className="mr-3"
                          disabled={generateDanceMutation.isPending}
                        />
                        <span className="text-sm">{label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Generate Button */}
                <Button
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                  onClick={handleGenerateVideo}
                  disabled={generateDanceMutation.isPending}
                >
                  {generateDanceMutation.isPending ? (
                    <>
                      <Loader className="h-4 w-4 mr-2 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Video className="h-4 w-4 mr-2" />
                      Gerar Vídeo
                    </>
                  )}
                </Button>

                <Link href="/dashboard">
                  <Button variant="outline" className="w-full">
                    Voltar
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Video Preview */}
          <div className="lg:col-span-2">
            {generatedVideo ? (
              <Card>
                <CardHeader>
                  <CardTitle>Vídeo Gerado</CardTitle>
                  <CardDescription>
                    {VIDEO_SIZES[size].label} - {CONTENT_TYPES[contentType].label}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Video Display */}
                  <div className="bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                    <video
                      src={generatedVideo}
                      controls
                      className="w-full h-auto"
                    />
                  </div>

                  {/* Info */}
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <p className="text-sm text-blue-700 dark:text-blue-300">
                      <strong>Música:</strong> {musicName}
                    </p>
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                      onClick={handleDownload}
                      disabled={downloading}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      {downloading ? "Baixando..." : "Baixar"}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleShare}
                    >
                      <Share2 className="h-4 w-4 mr-2" />
                      Compartilhar
                    </Button>
                  </div>

                  {/* Generate Another */}
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setGeneratedVideo(null)}
                  >
                    Gerar Outro Vídeo
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-12 pb-12 text-center">
                  <Video className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Preencha os dados e clique em "Gerar Vídeo" para começar
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

