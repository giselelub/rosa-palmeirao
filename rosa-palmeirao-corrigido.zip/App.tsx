import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Landing from "./pages/Landing";
import Dashboard from "./pages/Dashboard";
import Subscription from "./pages/SubscriptionNew";
import Demo from "./pages/Demo";
import Pricing from "./pages/Pricing";
import Login from "./pages/Login";
import Register from "./pages/Register";
import CharacterCreator from "./pages/CharacterCreator";
import AdCreativeGenerator from "./pages/AdCreativeGenerator";
import ContentViewer from "./pages/ContentViewer";
import GenerationGallery from "./pages/GenerationGallery";
import ImageGenerator from "./pages/ImageGenerator";
import DanceVideoGenerator from "./pages/DanceVideoGenerator";
import ChatInterface from "./pages/ChatInterface";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Landing} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/demo" component={Demo} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/characters/new" component={CharacterCreator} />
      <Route path="/ads/create" component={AdCreativeGenerator} />
      <Route path="/generate/:characterId/:type" component={ContentViewer} />
      <Route path="/gallery" component={GenerationGallery} />
      <Route path="/generate-image/:characterId" component={ImageGenerator} />
      <Route path="/generate-dance/:characterId" component={DanceVideoGenerator} />
      <Route path="/chat/:characterId" component={ChatInterface} />
      <Route path="/subscription" component={Subscription} />
      <Route path="/subscription/success" component={() => {
        // Redirect to subscription page after successful payment
        window.location.href = '/subscription';
        return null;
      }} />
      <Route path={"\/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
