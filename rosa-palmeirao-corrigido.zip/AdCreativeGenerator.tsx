import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, Download, Copy, RefreshCw, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

interface GeneratedCreative {
  platform: "facebook" | "tiktok" | "instagram" | "kwai";
  productName: string;
  imageUrl?: string;
  size: string;
  headline: string;
  description: string;
  ctaText: string;
}

const PLATFORM_SIZES = {
  facebook: ["1200x628", "1080x1080", "1080x1350"],
  tiktok: ["1080x1920", "720x1280"],
  instagram: ["1080x1080", "1080x1350", "1080x566"],
  kwai: ["1080x1920", "720x1280"],
};

const PLATFORM_INFO = {
  facebook: { emoji: "📘", name: "Facebook" },
  tiktok: { emoji: "🎵", name: "TikTok" },
  instagram: { emoji: "📷", name: "Instagram" },
  kwai: { emoji: "🎬", name: "Kwai" },
};

export default function AdCreativeGenerator() {
  const { t } = useTranslation();
  const [platform, setPlatform] = useState<"facebook" | "tiktok" | "instagram" | "kwai">("facebook");
  const [size, setSize] = useState(PLATFORM_SIZES.facebook[0]);
  const [productName, setProductName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [generatedCreatives, setGeneratedCreatives] = useState<GeneratedCreative[]>([]);
  const [error, setError] = useState("");

  // Usar mutação do tRPC
  const generateMutation = trpc.adCreative.generate.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setGeneratedCreatives([data.creative]);
        setError("");
      }
    },
    onError: (error) => {
      setError(error.message || "Erro ao gerar criativo");
    },
  });

  const generateBatchMutation = trpc.adCreative.generateBatch.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        // Converter para formato compatível
        const creatives = data.creatives.map((c) => ({
          platform: data.platform,
          productName: data.productName,
          size,
          headline: c.headline,
          description: c.description,
          ctaText: c.ctaText,
        }));
        setGeneratedCreatives(creatives);
        setError("");
      }
    },
    onError: (error) => {
      setError(error.message || "Erro ao gerar criativos");
    },
  });

  const handleGenerateCreative = async () => {
    if (!productName) {
      setError("Por favor, insira o nome do produto");
      return;
    }

    await generateMutation.mutateAsync({
      platform,
      productName,
      imageUrl: imageUrl || undefined,
      size,
    });
  };

  const handleGenerateBatch = async () => {
    if (!productName) {
      setError("Por favor, insira o nome do produto");
      return;
    }

    await generateBatchMutation.mutateAsync({
      platform,
      productName,
      quantity: 5,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Copiado para a área de transferência!");
  };

  const downloadCreative = (creative: GeneratedCreative, index: number) => {
    const content = `
CRIATIVO PARA ${creative.platform.toUpperCase()}
=====================================

Tamanho: ${creative.size}
Produto: ${creative.productName}

HEADLINE:
${creative.headline}

DESCRIÇÃO:
${creative.description}

BOTÃO CTA:
${creative.ctaText}

${creative.imageUrl ? `IMAGEM: ${creative.imageUrl}` : "IMAGEM: [Adicionar imagem aqui]"}

=====================================
Gerado em: ${new Date().toLocaleString("pt-BR")}
    `;

    const element = document.createElement("a");
    element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(content));
    element.setAttribute("download", `criativo_${creative.platform}_${index}_${Date.now()}.txt`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
        </div>
      </header>

      <div className="container py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Gerador de Criativos para Anúncios</h1>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Crie anúncios persuasivos e visuais para suas redes sociais em segundos
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Configurar Criativo</CardTitle>
                <CardDescription>Preencha os dados do seu produto</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {error && (
                  <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{error}</span>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium mb-2">Plataforma</label>
                  <select
                    className="w-full p-2 border rounded bg-white dark:bg-gray-800"
                    value={platform}
                    onChange={(e) => {
                      setPlatform(e.target.value as any);
                      setSize(PLATFORM_SIZES[e.target.value as any][0]);
                    }}
                  >
                    {Object.entries(PLATFORM_INFO).map(([key, { emoji, name }]) => (
                      <option key={key} value={key}>
                        {emoji} {name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Tamanho da Imagem</label>
                  <select
                    className="w-full p-2 border rounded bg-white dark:bg-gray-800"
                    value={size}
                    onChange={(e) => setSize(e.target.value)}
                  >
                    {PLATFORM_SIZES[platform].map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Nome do Produto *</label>
                  <Input
                    placeholder="Ex: Camiseta Premium, Tênis Esportivo"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">URL da Imagem (Opcional)</label>
                  <Input
                    placeholder="https://exemplo.com/imagem.jpg"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Deixe em branco para gerar sem imagem
                  </p>
                </div>

                <div className="space-y-2">
                  <Button
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                    onClick={handleGenerateCreative}
                    disabled={generateMutation.isPending}
                  >
                    {generateMutation.isPending ? "Gerando..." : "Gerar 1 Criativo"}
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleGenerateBatch}
                    disabled={generateBatchMutation.isPending}
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    {generateBatchMutation.isPending ? "Gerando..." : "Gerar 5 Criativos"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Preview Section */}
          <div className="lg:col-span-2">
            {generatedCreatives.length > 0 ? (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Pré-visualizações</h2>
                {generatedCreatives.map((creative, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Criativo {index + 1} - {PLATFORM_INFO[creative.platform].emoji} {PLATFORM_INFO[creative.platform].name}
                      </CardTitle>
                      <CardDescription>
                        Tamanho: {creative.size}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Mock Ad Preview */}
                      <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg border-2 border-gray-300 dark:border-gray-700">
                        <div className="bg-white dark:bg-gray-900 p-4 rounded">
                          {creative.imageUrl && (
                            <div className="mb-4 bg-gray-300 dark:bg-gray-700 rounded h-40 flex items-center justify-center overflow-hidden">
                              <img
                                src={creative.imageUrl}
                                alt="Produto"
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}

                          <h3 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">
                            {creative.headline}
                          </h3>
                          <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                            {creative.description}
                          </p>
                          <button className="w-full bg-blue-600 text-white py-2 rounded font-semibold hover:bg-blue-700 transition">
                            {creative.ctaText}
                          </button>
                        </div>
                      </div>

                      {/* Copy Buttons */}
                      <div className="space-y-2">
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => copyToClipboard(creative.headline)}
                        >
                          <Copy className="h-4 w-4 mr-2" />
                          Copiar Headline
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => copyToClipboard(creative.description)}
                        >
                          <Copy className="h-4 w-4 mr-2" />
                          Copiar Descrição
                        </Button>
                        <Button
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                          onClick={() => downloadCreative(creative, index + 1)}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Baixar Criativo
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-12 pb-12 text-center">
                  <Sparkles className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Preencha os dados e clique em "Gerar Criativo" para começar
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

