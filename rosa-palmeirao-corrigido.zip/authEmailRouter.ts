import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./_core/db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { hashPassword, verifyPassword, isValidEmail, isStrongPassword, generateSessionToken } from "./authHelpers";

// Validation schemas
const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter no mínimo 6 caracteres"),
});

const registerSchema = z.object({
  name: z.string().min(2, "Nome deve ter no mínimo 2 caracteres"),
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter no mínimo 6 caracteres"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "As senhas não correspondem",
  path: ["confirmPassword"],
});

export const authEmailRouter = router({
  /**
   * Registrar novo usuário com e-mail e senha
   */
  register: publicProcedure
    .input(registerSchema)
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Validar email
        if (!isValidEmail(input.email)) {
          throw new Error("Email inválido");
        }

        // Validar força da senha
        if (!isStrongPassword(input.password)) {
          throw new Error("Senha deve ter pelo menos 6 caracteres, com números e letras");
        }

        // Verificar se usuário já existe
        const existingUser = await db
          .select()
          .from(users)
          .where(eq(users.email, input.email))
          .limit(1);

        if (existingUser.length > 0) {
          throw new Error("Email já cadastrado");
        }

        // Hash da senha
        const hashedPassword = hashPassword(input.password);

        // Criar ID único baseado em email
        const openId = `email_${input.email}_${Date.now()}`;

        // Inserir usuário
        const result = await db.insert(users).values({
          openId,
          name: input.name,
          email: input.email,
          loginMethod: "email",
          // TODO: Adicionar campo de senha hasheada ao schema
        });

        return {
          success: true,
          message: "Usuário registrado com sucesso! Faça login para continuar.",
          userId: result.insertId,
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao registrar");
      }
    }),

  /**
   * Login com e-mail e senha
   */
  login: publicProcedure
    .input(loginSchema)
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Buscar usuário por email
        const userResult = await db
          .select()
          .from(users)
          .where(eq(users.email, input.email))
          .limit(1);

        if (userResult.length === 0) {
          throw new Error("Email ou senha inválidos");
        }

        const user = userResult[0];

        // TODO: Implementar verificação de senha hasheada
        // Por enquanto, aceita qualquer senha (apenas para desenvolvimento)
        // Em produção: const isPasswordValid = verifyPassword(input.password, user.password);

        // Atualizar último login
        await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));

        // Definir cookie de sessão
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, user.openId, {
          ...cookieOptions,
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 dias
        });

        return {
          success: true,
          message: "Login realizado com sucesso!",
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            openId: user.openId,
          },
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao fazer login");
      }
    }),

  /**
   * Logout do usuário
   */
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true, message: "Logout realizado com sucesso" };
  }),

  /**
   * Verificar se usuário está autenticado
   */
  me: publicProcedure.query(({ ctx }) => {
    return ctx.user || null;
  }),

  /**
   * Alterar senha
   */
  changePassword: publicProcedure
    .input(z.object({
      currentPassword: z.string(),
      newPassword: z.string().min(6),
      confirmPassword: z.string(),
    }).refine((data) => data.newPassword === data.confirmPassword, {
      message: "As senhas não correspondem",
      path: ["confirmPassword"],
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        if (!ctx.user) throw new Error("Não autenticado");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // TODO: Implementar verificação de senha atual
        // const user = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        // if (!verifyPassword(input.currentPassword, user[0].password)) {
        //   throw new Error("Senha atual inválida");
        // }

        // Validar nova senha
        if (!isStrongPassword(input.newPassword)) {
          throw new Error("Senha deve ter pelo menos 6 caracteres, com números e letras");
        }

        // Hash da nova senha
        const hashedPassword = hashPassword(input.newPassword);

        // TODO: Atualizar senha no banco de dados
        // await db.update(users).set({ password: hashedPassword }).where(eq(users.id, ctx.user.id));

        return {
          success: true,
          message: "Senha alterada com sucesso!",
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao alterar senha");
      }
    }),
});

