# 🚀 EXECUTE AGORA - 3 Passos Simples

Seu app está pronto! Agora você precisa fazer 3 coisas simples:

---

## ✅ Passo 1: Obter 3 Tokens (5 minutos)

### Token 1: GitHub

1. Abra: https://github.com/settings/tokens
2. Clique em "Generate new token"
3. Nome: `Rosa Palmeirao Deploy`
4. Selecione: `repo` e `workflow`
5. Clique em "Generate token"
6. **Copie o token** (você vai precisar)

### Token 2: Hugging Face

1. Abra: https://huggingface.co/settings/tokens
2. Clique em "New token"
3. Nome: `Rosa Palmeirao`
4. Tipo: `read`
5. Clique em "Generate token"
6. **Copie o token** (você vai precisar)

### Token 3: Vercel

1. Abra: https://vercel.com/account/tokens
2. Clique em "Create"
3. Nome: `Rosa Palmeirao Deploy`
4. Clique em "Create"
5. **Copie o token** (você vai precisar)

---

## ✅ Passo 2: Rodar o Script (10 minutos)

Abra o terminal/prompt de comando e execute:

```bash
cd /caminho/para/rosa-palmeirao
bash deploy.sh
```

O script vai pedir:
1. Seu username do GitHub
2. Seu token do GitHub (copie do passo anterior)
3. Seu token do Hugging Face (copie do passo anterior)
4. Seu token da Vercel (copie do passo anterior)
5. Sua connection string do banco de dados (vou explicar abaixo)

---

## ✅ Passo 3: Criar Banco de Dados (5 minutos)

Quando o script pedir a connection string do banco de dados:

1. Abra: https://vercel.com/dashboard/stores
2. Clique em "Create Database"
3. Selecione "Postgres"
4. Escolha a região mais próxima (ex: São Paulo)
5. Clique em "Create"
6. Abra a aba "Postgres"
7. Clique em ".env.local"
8. **Copie a connection string** (tipo: `postgresql://user:password@host/database`)
9. Cole no script

---

## 🎉 Pronto!

Quando o script terminar, você receberá um link como:

```
🌐 Seu link: https://rosa-palmeirao.vercel.app
```

**Seu app está online e pronto para usar!** 🚀

---

## 📌 Resumo

| Passo | Tempo | O que fazer |
|-------|-------|-----------|
| 1 | 5 min | Obter 3 tokens |
| 2 | 10 min | Rodar script |
| 3 | 5 min | Criar banco de dados |
| **Total** | **20 min** | **App online!** |

---

## 🆘 Se Tiver Dúvida

### "Onde está o script?"
Está em: `/rosa-palmeirao/deploy.sh`

### "Como executo no Windows?"
Instale Git Bash: https://git-scm.com/download/win

Depois execute:
```bash
bash deploy.sh
```

### "Como executo no Mac?"
Abra o Terminal e execute:
```bash
bash deploy.sh
```

### "Como executo no Linux?"
Abra o Terminal e execute:
```bash
bash deploy.sh
```

---

## ✨ Depois que Terminar

1. Acesse seu link
2. Clique em "Cadastre-se"
3. Use seu email: `giselelubanco2@gmail.com`
4. Crie uma senha
5. Comece a usar!

---

**Você consegue! 💪**

Se tiver problemas, verifique os logs do script ou entre em contato.

