import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, ChevronLeft, ChevronRight, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

type Step = "basic" | "physical" | "style" | "personality" | "preview";

interface CharacterData {
  name: string;
  // Physical attributes
  ethnicity: string;
  hairColor: string;
  hairStyle: string;
  eyeColor: string;
  faceShape: string;
  bodyType: string;
  // Style attributes
  mainOutfit: string;
  accessories: string[];
  colorPalette: string[];
  scenario: string;
  // Personality attributes
  archetype: string;
  voiceTone: string;
  interests: string[];
  contentRating: "glamour" | "spicy" | "adult";
}

export default function CharacterCreator() {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<Step>("basic");
  const [character, setCharacter] = useState<CharacterData>({
    name: "",
    ethnicity: "",
    hairColor: "",
    hairStyle: "",
    eyeColor: "",
    faceShape: "",
    bodyType: "",
    mainOutfit: "",
    accessories: [],
    colorPalette: [],
    scenario: "",
    archetype: "",
    voiceTone: "",
    interests: [],
    contentRating: "glamour",
  });
  const [error, setError] = useState("");

  // Usar mutação do tRPC
  const createCharacterMutation = trpc.character.save.create.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        // Redirecionar para dashboard após criar personagem
        setLocation("/dashboard");
      }
    },
    onError: (error) => {
      setError(error.message || "Erro ao salvar personagem");
    },
  });

  const handleInputChange = (field: keyof CharacterData, value: any) => {
    setCharacter((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleAddAccessory = (accessory: string) => {
    if (accessory && !character.accessories.includes(accessory)) {
      handleInputChange("accessories", [...character.accessories, accessory]);
    }
  };

  const handleRemoveAccessory = (index: number) => {
    handleInputChange(
      "accessories",
      character.accessories.filter((_, i) => i !== index)
    );
  };

  const handleAddInterest = (interest: string) => {
    if (interest && !character.interests.includes(interest)) {
      handleInputChange("interests", [...character.interests, interest]);
    }
  };

  const handleRemoveInterest = (index: number) => {
    handleInputChange(
      "interests",
      character.interests.filter((_, i) => i !== index)
    );
  };

  const handleSaveCharacter = async () => {
    if (!character.name) {
      setError("Nome do personagem é obrigatório");
      return;
    }

    await createCharacterMutation.mutateAsync(character);
  };

  const nextStep = () => {
    const steps: Step[] = ["basic", "physical", "style", "personality", "preview"];
    const currentIndex = steps.indexOf(step);
    if (currentIndex < steps.length - 1) {
      setStep(steps[currentIndex + 1]);
    }
  };

  const prevStep = () => {
    const steps: Step[] = ["basic", "physical", "style", "personality", "preview"];
    const currentIndex = steps.indexOf(step);
    if (currentIndex > 0) {
      setStep(steps[currentIndex - 1]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
        </div>
      </header>

      <div className="container py-8 max-w-2xl">
        <h1 className="text-3xl font-bold mb-8">Criar Novo Personagem</h1>

        {error && (
          <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded mb-6 flex items-start gap-2">
            <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle>
              {step === "basic" && "Informações Básicas"}
              {step === "physical" && "Atributos Físicos"}
              {step === "style" && "Estilo e Aparência"}
              {step === "personality" && "Personalidade"}
              {step === "preview" && "Pré-visualização"}
            </CardTitle>
            <CardDescription>
              Passo {["basic", "physical", "style", "personality", "preview"].indexOf(step) + 1} de 5
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1: Basic Info */}
            {step === "basic" && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Nome do Personagem *</label>
                  <Input
                    placeholder="Ex: Rosa, Luna, Sofia"
                    value={character.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Categoria de Conteúdo</label>
                  <select
                    className="w-full p-2 border rounded bg-white dark:bg-gray-800"
                    value={character.contentRating}
                    onChange={(e) =>
                      handleInputChange(
                        "contentRating",
                        e.target.value as "glamour" | "spicy" | "adult"
                      )
                    }
                  >
                    <option value="glamour">🌸 Glamour (Elegante e sofisticado)</option>
                    <option value="spicy">🌶️ Spicy (Ousado e provocante)</option>
                    <option value="adult">🔞 Adult (Conteúdo +18)</option>
                  </select>
                </div>
              </div>
            )}

            {/* Step 2: Physical Attributes */}
            {step === "physical" && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Etnia</label>
                  <Input
                    placeholder="Ex: Caucasiana, Latina, Asiática, Negra"
                    value={character.ethnicity}
                    onChange={(e) => handleInputChange("ethnicity", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Cor do Cabelo</label>
                  <Input
                    placeholder="Ex: Loiro platinado, Preto azulado, Ruivo"
                    value={character.hairColor}
                    onChange={(e) => handleInputChange("hairColor", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Estilo de Cabelo</label>
                  <Input
                    placeholder="Ex: Longo e ondulado, Curto e reto, Coque alto"
                    value={character.hairStyle}
                    onChange={(e) => handleInputChange("hairStyle", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Cor dos Olhos</label>
                  <Input
                    placeholder="Ex: Azuis cristalinos, Verdes esmeralda, Castanhos"
                    value={character.eyeColor}
                    onChange={(e) => handleInputChange("eyeColor", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Formato do Rosto</label>
                  <Input
                    placeholder="Ex: Oval, Coração, Quadrado, Redondo"
                    value={character.faceShape}
                    onChange={(e) => handleInputChange("faceShape", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Tipo de Corpo</label>
                  <Input
                    placeholder="Ex: Atlético, Curvilíneo, Esbelto"
                    value={character.bodyType}
                    onChange={(e) => handleInputChange("bodyType", e.target.value)}
                  />
                </div>
              </div>
            )}

            {/* Step 3: Style */}
            {step === "style" && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Vestimenta Principal</label>
                  <Input
                    placeholder="Ex: Vestido de gala de seda preta, Biquíni de grife"
                    value={character.mainOutfit}
                    onChange={(e) => handleInputChange("mainOutfit", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Acessórios</label>
                  <div className="flex gap-2 mb-2">
                    <Input
                      placeholder="Ex: Colar de diamantes"
                      id="accessoryInput"
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          const input = e.currentTarget;
                          handleAddAccessory(input.value);
                          input.value = "";
                        }
                      }}
                    />
                    <Button
                      type="button"
                      onClick={() => {
                        const input = document.getElementById(
                          "accessoryInput"
                        ) as HTMLInputElement;
                        handleAddAccessory(input.value);
                        input.value = "";
                      }}
                    >
                      Adicionar
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {character.accessories.map((acc, idx) => (
                      <div
                        key={idx}
                        className="bg-pink-100 text-pink-700 px-3 py-1 rounded-full flex items-center gap-2"
                      >
                        {acc}
                        <button
                          type="button"
                          onClick={() => handleRemoveAccessory(idx)}
                          className="text-pink-700 hover:text-pink-900"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Cenário</label>
                  <Input
                    placeholder="Ex: Varanda de hotel 5 estrelas em Dubai, Beco de neon em Tóquio"
                    value={character.scenario}
                    onChange={(e) => handleInputChange("scenario", e.target.value)}
                  />
                </div>
              </div>
            )}

            {/* Step 4: Personality */}
            {step === "personality" && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Arquétipo</label>
                  <Input
                    placeholder="Ex: Femme Fatale, Sonhadora, Intelectual, Rebelde"
                    value={character.archetype}
                    onChange={(e) => handleInputChange("archetype", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Tom de Voz</label>
                  <Input
                    placeholder="Ex: Misterioso e provocante, Doce e encantador"
                    value={character.voiceTone}
                    onChange={(e) => handleInputChange("voiceTone", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Interesses</label>
                  <div className="flex gap-2 mb-2">
                    <Input
                      placeholder="Ex: Arte contemporânea"
                      id="interestInput"
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          const input = e.currentTarget;
                          handleAddInterest(input.value);
                          input.value = "";
                        }
                      }}
                    />
                    <Button
                      type="button"
                      onClick={() => {
                        const input = document.getElementById(
                          "interestInput"
                        ) as HTMLInputElement;
                        handleAddInterest(input.value);
                        input.value = "";
                      }}
                    >
                      Adicionar
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {character.interests.map((interest, idx) => (
                      <div
                        key={idx}
                        className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full flex items-center gap-2"
                      >
                        {interest}
                        <button
                          type="button"
                          onClick={() => handleRemoveInterest(idx)}
                          className="text-purple-700 hover:text-purple-900"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 5: Preview */}
            {step === "preview" && (
              <div className="space-y-4">
                <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg">{character.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {character.contentRating === "glamour" && "🌸 Glamour"}
                      {character.contentRating === "spicy" && "🌶️ Spicy"}
                      {character.contentRating === "adult" && "🔞 Adult"}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm mb-2">Atributos Físicos</h4>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      {character.ethnicity}, cabelo {character.hairColor} ({character.hairStyle}),
                      olhos {character.eyeColor}, rosto {character.faceShape}, corpo {character.bodyType}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm mb-2">Estilo</h4>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      {character.mainOutfit}
                    </p>
                    {character.accessories.length > 0 && (
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        Acessórios: {character.accessories.join(", ")}
                      </p>
                    )}
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      Cenário: {character.scenario}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm mb-2">Personalidade</h4>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      Arquétipo: {character.archetype}
                    </p>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      Tom: {character.voiceTone}
                    </p>
                    {character.interests.length > 0 && (
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        Interesses: {character.interests.join(", ")}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex gap-4 justify-between pt-6 border-t">
              <Button
                variant="outline"
                onClick={prevStep}
                disabled={step === "basic"}
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Anterior
              </Button>

              {step === "preview" ? (
                <Button
                  className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                  onClick={handleSaveCharacter}
                  disabled={createCharacterMutation.isPending}
                >
                  {createCharacterMutation.isPending ? "Salvando..." : "Salvar Personagem"}
                </Button>
              ) : (
                <Button onClick={nextStep}>
                  Próximo
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

