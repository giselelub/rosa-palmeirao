import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./_core/db";
import { characters } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Validation schema para criar personagem
const createCharacterSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  ethnicity: z.string().optional(),
  hairColor: z.string().optional(),
  hairStyle: z.string().optional(),
  eyeColor: z.string().optional(),
  faceShape: z.string().optional(),
  bodyType: z.string().optional(),
  mainOutfit: z.string().optional(),
  accessories: z.array(z.string()).optional(),
  colorPalette: z.array(z.string()).optional(),
  scenario: z.string().optional(),
  archetype: z.string().optional(),
  voiceTone: z.string().optional(),
  interests: z.array(z.string()).optional(),
  contentRating: z.enum(["glamour", "spicy", "adult"]).default("glamour"),
  imageStyle: z.enum(["realistic", "anime"]).default("realistic"),
});

export const characterSaveRouter = router({
  /**
   * Criar novo personagem
   */
  create: publicProcedure
    .input(createCharacterSchema)
    .mutation(async ({ input, ctx }) => {
      try {
        if (!ctx.user) throw new Error("Não autenticado");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const result = await db.insert(characters).values({
          userId: ctx.user.id,
          name: input.name,
          ethnicity: input.ethnicity,
          hairColor: input.hairColor,
          hairStyle: input.hairStyle,
          eyeColor: input.eyeColor,
          faceShape: input.faceShape,
          bodyType: input.bodyType,
          mainOutfit: input.mainOutfit,
          accessories: JSON.stringify(input.accessories || []),
          colorPalette: JSON.stringify(input.colorPalette || []),
          scenario: input.scenario,
          archetype: input.archetype,
          voiceTone: input.voiceTone,
          interests: JSON.stringify(input.interests || []),
          contentRating: input.contentRating,
          imageStyle: input.imageStyle,
        });

        return {
          success: true,
          message: "Personagem criado com sucesso!",
          characterId: result.insertId,
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao criar personagem");
      }
    }),

  /**
   * Listar personagens do usuário
   */
  list: publicProcedure.query(async ({ ctx }) => {
    try {
      if (!ctx.user) throw new Error("Não autenticado");

      const db = await getDb();
      if (!db) return [];

      const userCharacters = await db
        .select()
        .from(characters)
        .where(eq(characters.userId, ctx.user.id));

      // Parsear JSON fields
      return userCharacters.map((char) => ({
        ...char,
        accessories: JSON.parse(char.accessories || "[]"),
        colorPalette: JSON.parse(char.colorPalette || "[]"),
        interests: JSON.parse(char.interests || "[]"),
      }));
    } catch (error) {
      console.error("Erro ao listar personagens:", error);
      return [];
    }
  }),

  /**
   * Obter personagem por ID
   */
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      try {
        if (!ctx.user) throw new Error("Não autenticado");

        const db = await getDb();
        if (!db) return null;

        const result = await db
          .select()
          .from(characters)
          .where(eq(characters.id, input.id))
          .limit(1);

        if (result.length === 0) return null;

        const char = result[0];

        // Verificar se pertence ao usuário
        if (char.userId !== ctx.user.id) {
          throw new Error("Acesso negado");
        }

        return {
          ...char,
          accessories: JSON.parse(char.accessories || "[]"),
          colorPalette: JSON.parse(char.colorPalette || "[]"),
          interests: JSON.parse(char.interests || "[]"),
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao obter personagem");
      }
    }),

  /**
   * Atualizar personagem
   */
  update: publicProcedure
    .input(z.object({
      id: z.number(),
      ...createCharacterSchema.shape,
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        if (!ctx.user) throw new Error("Não autenticado");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Verificar se personagem pertence ao usuário
        const existing = await db
          .select()
          .from(characters)
          .where(eq(characters.id, input.id))
          .limit(1);

        if (existing.length === 0 || existing[0].userId !== ctx.user.id) {
          throw new Error("Personagem não encontrado");
        }

        await db.update(characters).set({
          name: input.name,
          ethnicity: input.ethnicity,
          hairColor: input.hairColor,
          hairStyle: input.hairStyle,
          eyeColor: input.eyeColor,
          faceShape: input.faceShape,
          bodyType: input.bodyType,
          mainOutfit: input.mainOutfit,
          accessories: JSON.stringify(input.accessories || []),
          colorPalette: JSON.stringify(input.colorPalette || []),
          scenario: input.scenario,
          archetype: input.archetype,
          voiceTone: input.voiceTone,
          interests: JSON.stringify(input.interests || []),
          contentRating: input.contentRating,
          imageStyle: input.imageStyle,
        }).where(eq(characters.id, input.id));

        return {
          success: true,
          message: "Personagem atualizado com sucesso!",
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao atualizar personagem");
      }
    }),

  /**
   * Deletar personagem
   */
  delete: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        if (!ctx.user) throw new Error("Não autenticado");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Verificar se personagem pertence ao usuário
        const existing = await db
          .select()
          .from(characters)
          .where(eq(characters.id, input.id))
          .limit(1);

        if (existing.length === 0 || existing[0].userId !== ctx.user.id) {
          throw new Error("Personagem não encontrado");
        }

        await db.delete(characters).where(eq(characters.id, input.id));

        return {
          success: true,
          message: "Personagem deletado com sucesso!",
        };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao deletar personagem");
      }
    }),
});

