import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Download, Trash2, Share2, Filter } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

type FilterType = "all" | "image" | "animation" | "chat";

export default function GenerationGallery() {
  const { t } = useTranslation();
  const [filter, setFilter] = useState<FilterType>("all");
  const [downloading, setDownloading] = useState<number | null>(null);

  // Obter histórico de gerações
  const { data: history = [], isLoading, refetch } = trpc.contentGeneration.getHistory.useQuery();

  // Deletar geração
  const deleteGenerationMutation = trpc.contentGeneration.deleteGeneration.useMutation({
    onSuccess: () => {
      refetch();
    },
  });

  const filteredHistory = history.filter((item) => {
    if (filter === "all") return true;
    return item.type === filter;
  });

  const handleDownload = async (url: string, filename: string, index: number) => {
    setDownloading(index);
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert("Erro ao baixar arquivo");
    } finally {
      setDownloading(null);
    }
  };

  const handleShare = (url: string) => {
    if (navigator.share) {
      navigator.share({
        title: "Confira meu conteúdo gerado!",
        url: url,
      });
    } else {
      navigator.clipboard.writeText(url);
      alert("Link copiado para a área de transferência!");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Tem certeza que deseja deletar este conteúdo?")) {
      await deleteGenerationMutation.mutateAsync({ id });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white dark:from-gray-900 dark:via-purple-900/20 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
              <Sparkles className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                Rosa Palmeirão
              </span>
            </div>
          </Link>
        </div>
      </header>

      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Galeria de Gerações</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Visualize, baixe e compartilhe todo seu conteúdo gerado
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 flex gap-2 flex-wrap">
          <Button
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
          >
            <Filter className="h-4 w-4 mr-2" />
            Todos ({history.length})
          </Button>
          <Button
            variant={filter === "image" ? "default" : "outline"}
            onClick={() => setFilter("image")}
          >
            Imagens ({history.filter((h) => h.type === "image").length})
          </Button>
          <Button
            variant={filter === "animation" ? "default" : "outline"}
            onClick={() => setFilter("animation")}
          >
            Vídeos ({history.filter((h) => h.type === "animation").length})
          </Button>
          <Button
            variant={filter === "chat" ? "default" : "outline"}
            onClick={() => setFilter("chat")}
          >
            Chats ({history.filter((h) => h.type === "chat").length})
          </Button>
        </div>

        {/* Gallery Grid */}
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Carregando...</p>
          </div>
        ) : filteredHistory.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredHistory.map((item, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition">
                <div className="relative bg-gray-100 dark:bg-gray-800 h-48 overflow-hidden">
                  {/* Image Preview */}
                  {item.type === "image" && item.resultUrl && (
                    <img
                      src={item.resultUrl}
                      alt="Generated"
                      className="w-full h-full object-cover hover:scale-105 transition"
                    />
                  )}

                  {/* Video Preview */}
                  {item.type === "animation" && item.resultUrl && (
                    <div className="w-full h-full flex items-center justify-center bg-gray-800">
                      <video
                        src={item.resultUrl}
                        className="w-full h-full object-cover"
                        onMouseEnter={(e) => e.currentTarget.play()}
                        onMouseLeave={(e) => e.currentTarget.pause()}
                      />
                    </div>
                  )}

                  {/* Chat Preview */}
                  {item.type === "chat" && (
                    <div className="w-full h-full flex items-center justify-center bg-blue-50 dark:bg-blue-900/20">
                      <div className="text-center p-4">
                        <p className="text-sm text-gray-700 dark:text-gray-300 line-clamp-3">
                          {item.prompt}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Type Badge */}
                  <div className="absolute top-2 right-2 bg-black/50 text-white px-2 py-1 rounded text-xs">
                    {item.type === "image" && "📷 Imagem"}
                    {item.type === "animation" && "🎬 Vídeo"}
                    {item.type === "chat" && "💬 Chat"}
                  </div>
                </div>

                <CardContent className="pt-4">
                  <div className="text-xs text-gray-500 mb-3">
                    {new Date(item.createdAt).toLocaleDateString("pt-BR", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-3 gap-2">
                    {(item.type === "image" || item.type === "animation") && item.resultUrl && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            handleDownload(
                              item.resultUrl!,
                              `${item.type}_${Date.now()}.${item.type === "image" ? "png" : "mp4"}`
                            )
                          }
                          disabled={downloading === index}
                          title="Baixar"
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleShare(item.resultUrl!)}
                          title="Compartilhar"
                        >
                          <Share2 className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(item.id)}
                          title="Deletar"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <Sparkles className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                Nenhum conteúdo gerado ainda
              </p>
              <Link href="/dashboard">
                <Button className="bg-gradient-to-r from-pink-500 to-purple-600">
                  Criar Personagem e Gerar Conteúdo
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

