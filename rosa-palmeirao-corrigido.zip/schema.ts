import { pgTable, serial, varchar, text, timestamp, integer, pgEnum } from "drizzle-orm/pg-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = pgTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: serial("id").primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: pgEnum("role", ["user", "admin"])("role").default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Subscriptions table - tracks user subscription status
 */
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  paypalSubscriptionId: varchar("paypalSubscriptionId", { length: 255 }),
  plan: pgEnum("plan", ["basic", "premium", "vip", "ultimate"])("plan").default("basic").notNull(),
  status: pgEnum("status", ["active", "cancelled", "expired", "pending"])("status").default("pending").notNull(),
  currency: pgEnum("currency", ["BRL", "USD", "EUR"])("currency").default("BRL").notNull(),
  amount: integer("amount").notNull(), // Amount in cents
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  ageVerified: integer("ageVerified").default(0).notNull(),
  ageVerifiedAt: timestamp("ageVerifiedAt"),
  dailyImageCount: integer("dailyImageCount").default(0).notNull(),
  dailyAnimationCount: integer("dailyAnimationCount").default(0).notNull(),
  lastResetDate: timestamp("lastResetDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Characters table - stores user-created digital influencer characters
 */
export const characters = pgTable("characters", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  ethnicity: varchar("ethnicity", { length: 100 }),
  hairColor: varchar("hairColor", { length: 100 }),
  hairStyle: varchar("hairStyle", { length: 100 }),
  eyeColor: varchar("eyeColor", { length: 100 }),
  faceShape: varchar("faceShape", { length: 100 }),
  bodyType: varchar("bodyType", { length: 100 }),
  mainOutfit: text("mainOutfit"),
  accessories: text("accessories"),
  colorPalette: text("colorPalette"),
  scenario: text("scenario"),
  archetype: varchar("archetype", { length: 100 }),
  voiceTone: varchar("voiceTone", { length: 100 }),
  interests: text("interests"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});

export type Character = typeof characters.$inferSelect;
export type InsertCharacter = typeof characters.$inferInsert;

/**
 * Generated content table - stores images, videos, and other generated content
 */
export const generatedContent = pgTable("generatedContent", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  characterId: integer("characterId").references(() => characters.id, { onDelete: "cascade" }),
  contentType: pgEnum("contentType", ["image", "video", "animation", "chat"])("contentType").notNull(),
  contentUrl: text("contentUrl").notNull(),
  prompt: text("prompt"),
  metadata: text("metadata"), // JSON string for additional data
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GeneratedContent = typeof generatedContent.$inferSelect;
export type InsertGeneratedContent = typeof generatedContent.$inferInsert;

