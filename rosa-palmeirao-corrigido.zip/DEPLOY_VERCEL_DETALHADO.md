# 🚀 Deploy na Vercel - Guia SUPER Detalhado

Vou explicar cada passo com detalhes!

---

## 📋 Passo 1: Abrir Vercel

### 1.1 Abra este link no navegador:
```
https://vercel.com/new
```

Você vai ver uma página com o título "Create a new project" ou "Import Project"

---

## 📋 Passo 2: Importar Repositório GitHub

### 2.1 Você vai ver um campo grande que diz:
```
"Enter a Git repository URL"
ou
"Paste the URL of your Git repository"
```

### 2.2 Cole este link no campo:
```
https://github.com/giselelub/rosa-palmeirao
```

### 2.3 Clique no botão:
```
"Import" ou "Continue"
```

---

## 📋 Passo 3: Configurar o Projeto

### 3.1 Você vai ver uma página com:
- **Project Name:** `rosa-palmeirao` (deixe assim)
- **Framework:** Deixe como está
- **Root Directory:** Deixe como está

### 3.2 Procure por uma seção chamada:
```
"Environment Variables"
ou
"Configure Environment"
```

Se não encontrar, **scroll para baixo** (desça a página)

---

## 📋 Passo 4: Adicionar Variáveis de Ambiente

### 4.1 Você vai ver um botão que diz:
```
"Add New" ou "Add Environment Variable"
```

### 4.2 Clique nele 4 vezes (para adicionar 4 variáveis)

---

## 📋 Primeira Variável (DATABASE_URL)

### 4.3 Quando clicar em "Add New", você vai ver 2 campos:

**Campo 1 (Name):**
```
Digite: DATABASE_URL
```

**Campo 2 (Value):**
```
Cole: postgresql://postgres:890098Gi@db.apbkobhfnmcqqzqeeqss.supabase.co:5432/postgres
```

### 4.4 Clique em "Add" ou "Save"

---

## 📋 Segunda Variável (HUGGING_FACE_API_KEY)

### 4.5 Clique novamente em "Add New"

**Campo 1 (Name):**
```
Digite: HUGGING_FACE_API_KEY
```

**Campo 2 (Value):**
```
Digite: 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
```

### 4.6 Clique em "Add" ou "Save"

---

## 📋 Terceira Variável (VITE_APP_TITLE)

### 4.7 Clique novamente em "Add New"

**Campo 1 (Name):**
```
Digite: VITE_APP_TITLE
```

**Campo 2 (Value):**
```
Digite: Rosa Palmeirão
```

### 4.8 Clique em "Add" ou "Save"

---

## 📋 Quarta Variável (NODE_ENV)

### 4.9 Clique novamente em "Add New"

**Campo 1 (Name):**
```
Digite: NODE_ENV
```

**Campo 2 (Value):**
```
Digite: production
```

### 4.10 Clique em "Add" ou "Save"

---

## 📋 Passo 5: Fazer Deploy

### 5.1 Procure por um botão grande que diz:
```
"Deploy" ou "Create"
```

### 5.2 Clique nele

---

## ⏳ Passo 6: Aguardar Deploy

### 6.1 Você vai ver uma tela com:
```
"Building..." ou "Deploying..."
```

### 6.2 Aguarde 3-5 minutos

A página vai mostrar o progresso. Você vai ver:
- ✅ Cloning repository
- ✅ Installing dependencies
- ✅ Building
- ✅ Deploying

---

## 🎉 Passo 7: Seu App Está Online!

### 7.1 Quando terminar, você vai receber um link como:
```
https://rosa-palmeirao.vercel.app
```

### 7.2 Clique no link para abrir seu app!

---

## ✅ Testar o App

### 7.3 Quando abrir, você vai ver a página inicial

### 7.4 Clique em "Cadastre-se"

### 7.5 Preencha:
- Email: `giselelubanco2@gmail.com`
- Senha: Crie uma senha
- Confirmar: Digite a mesma senha

### 7.6 Clique em "Cadastrar"

### 7.7 Faça login com o email e senha

### 7.8 Você deve ver o Dashboard!

---

## 🎊 Pronto!

Seu app está online e funcionando! 🚀

---

## 📊 Resumo das Variáveis:

| Nome | Valor |
|------|-------|
| DATABASE_URL | postgresql://postgres:890098Gi@db.apbkobhfnmcqqzqeeqss.supabase.co:5432/postgres |
| HUGGING_FACE_API_KEY | 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 |
| VITE_APP_TITLE | Rosa Palmeirão |
| NODE_ENV | production |

---

## 🆘 Se Tiver Dúvida

### "Não encontro Environment Variables"
- Scroll para baixo (desça a página)
- Procure por "Configure"
- Procure por "Environment"

### "Não consigo colar o texto"
- Clique no campo
- Pressione Ctrl+V (Windows) ou Cmd+V (Mac)

### "Erro ao fazer deploy"
- Verifique se todas as variáveis estão corretas
- Tente fazer novo deploy

---

**Você consegue! 💪**

Se tiver dúvida em qualquer passo, me avisa!

