# ⚡ Deploy Rápido - Rosa Palmeirão

Se você já leu o **GUIA_COMPLETO_LANCAMENTO_GRATUITO.md**, este documento oferece um resumo rápido dos comandos essenciais.

---

## 🚀 Resumo Rápido (5 Minutos)

### 1. Preparar o Repositório GitHub

```bash
git init
git add .
git commit -m "Initial commit: Rosa Palmeirão"
git branch -M main
git remote add origin https://github.com/seu-usuario/rosa-palmeirao.git
git push -u origin main
```

### 2. Configurar Banco de Dados (Neon)

1. Acesse [console.neon.tech](https://console.neon.tech)
2. Crie um novo projeto
3. Copie a string de conexão
4. Atualize o `.env`:
   ```bash
   DATABASE_URL="postgresql://user:password@ep-xxxxx.us-east-1.aws.neon.tech/rosa_db?sslmode=require"
   ```

### 3. Deploy do Frontend (Vercel)

1. Acesse [vercel.com](https://vercel.com)
2. Clique em **"New Project"**
3. Selecione seu repositório GitHub
4. Adicione variáveis de ambiente:
   - `VITE_API_URL`: `https://seu-backend-render.onrender.com`
5. Clique em **"Deploy"**

### 4. Deploy do Backend (Render)

1. Acesse [render.com](https://render.com)
2. Clique em **"New Web Service"**
3. Selecione seu repositório GitHub
4. Configure:
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Plan:** Free
5. Adicione todas as variáveis de ambiente (veja `GUIA_COMPLETO_LANCAMENTO_GRATUITO.md`)
6. Clique em **"Create Web Service"**

### 5. Configurar Chaves de API

Obtenha as chaves dos seguintes serviços e adicione ao Render:

- **Hugging Face:** [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens)
- **OpenAI:** [platform.openai.com/api-keys](https://platform.openai.com/api-keys)
- **Cloudinary:** [cloudinary.com/console](https://cloudinary.com/console)
- **Resend:** [resend.com/api-keys](https://resend.com/api-keys)
- **PayPal:** [developer.paypal.com](https://developer.paypal.com)

---

## 🔄 Atualizar Após Mudanças

Sempre que fizer mudanças no código:

```bash
git add .
git commit -m "Descrição da mudança"
git push origin main
```

O Vercel e Render farão o deploy automaticamente.

---

## 📊 Monitorar Status

- **Vercel:** [vercel.com/dashboard](https://vercel.com/dashboard)
- **Render:** [render.com/dashboard](https://render.com/dashboard)
- **Neon:** [console.neon.tech](https://console.neon.tech)

---

## 🆘 Problemas Comuns

| Problema | Solução |
| :--- | :--- |
| "DATABASE_URL not set" | Configure a variável no Render |
| "Connection refused" | Verifique se o backend está rodando |
| "API key invalid" | Verifique as chaves no Render |
| "Build failed" | Verifique os logs no Vercel/Render |

---

**Pronto! Seu aplicativo está no ar! 🎉**

