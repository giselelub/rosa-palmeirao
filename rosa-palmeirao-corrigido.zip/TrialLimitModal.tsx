import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Lock, Sparkles } from "lucide-react";
import { Link } from "wouter";

interface TrialLimitModalProps {
  feature: string;
  isOpen: boolean;
  onClose: () => void;
  hasSubscription: boolean;
  trialUsed: number;
  trialLimit: number;
  canDownload: boolean;
}

export default function TrialLimitModal({
  feature,
  isOpen,
  onClose,
  hasSubscription,
  trialUsed,
  trialLimit,
  canDownload,
}: TrialLimitModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2">
            {canDownload ? (
              <Sparkles className="h-6 w-6 text-green-500" />
            ) : (
              <Lock className="h-6 w-6 text-orange-500" />
            )}
            <CardTitle>
              {canDownload ? "✅ Acesso Completo" : "🔒 Teste Gratuito"}
            </CardTitle>
          </div>
          <CardDescription>
            {feature}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {canDownload ? (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <p className="text-sm text-green-700 dark:text-green-300">
                  <strong>✅ Assinatura Ativa</strong>
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                  Você tem acesso ilimitado a todas as funcionalidades e pode fazer download do conteúdo.
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Seus Benefícios:</h4>
                <ul className="text-sm space-y-1 text-gray-700 dark:text-gray-300">
                  <li>✅ Gerar conteúdo ilimitado</li>
                  <li>✅ Download em alta qualidade</li>
                  <li>✅ Compartilhamento ilimitado</li>
                  <li>✅ Sem anúncios</li>
                  <li>✅ Prioridade no suporte</li>
                </ul>
              </div>

              <Button
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600"
                onClick={onClose}
              >
                Continuar Gerando
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg">
                <p className="text-sm text-orange-700 dark:text-orange-300">
                  <strong>⚠️ Teste Gratuito</strong>
                </p>
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">
                  Você pode gerar conteúdo, mas não consegue fazer download.
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Seu Uso:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Testes usados:</span>
                    <span className="font-bold">
                      {trialUsed} / {trialLimit}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-orange-500 h-full transition-all"
                      style={{ width: `${(trialUsed / trialLimit) * 100}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <p className="text-xs text-blue-700 dark:text-blue-300">
                  <strong>💡 Dica:</strong> Faça upgrade para desbloquear downloads ilimitados e acesso a todas as funcionalidades!
                </p>
              </div>

              <div className="space-y-2">
                <Link href="/subscription">
                  <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
                    <Sparkles className="h-4 w-4 mr-2" />
                    Fazer Upgrade Agora
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={onClose}
                >
                  Ver Pré-visualização
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

