#!/bin/bash

# ============================================
# Rosa Palmeirão - Script de Deploy Automático
# ============================================
# Este script configura e faz deploy do aplicativo automaticamente

set -e  # Parar se houver erro

echo "🚀 Rosa Palmeirão - Deploy Automático"
echo "======================================"
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ============================================
# PASSO 1: Verificar Pré-requisitos
# ============================================
echo -e "${BLUE}📋 Verificando pré-requisitos...${NC}"

# Verificar Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js não encontrado. Instale em: https://nodejs.org/${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Node.js encontrado: $(node --version)${NC}"

# Verificar npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm não encontrado${NC}"
    exit 1
fi
echo -e "${GREEN}✅ npm encontrado: $(npm --version)${NC}"

# Verificar git
if ! command -v git &> /dev/null; then
    echo -e "${RED}❌ Git não encontrado. Instale em: https://git-scm.com/${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Git encontrado: $(git --version)${NC}"

echo ""

# ============================================
# PASSO 2: Coletar Informações do Usuário
# ============================================
echo -e "${BLUE}📝 Coletando informações...${NC}"
echo ""

# Email
EMAIL="giselelubanco2@gmail.com"
echo -e "Email: ${YELLOW}$EMAIL${NC}"

# GitHub Username
read -p "Digite seu username do GitHub: " GITHUB_USERNAME
if [ -z "$GITHUB_USERNAME" ]; then
    echo -e "${RED}❌ Username do GitHub é obrigatório${NC}"
    exit 1
fi

# GitHub Token
echo ""
echo -e "${YELLOW}⚠️  Você precisa criar um token no GitHub:${NC}"
echo "1. Acesse: https://github.com/settings/tokens"
echo "2. Clique em 'Generate new token'"
echo "3. Selecione 'repo' e 'workflow'"
echo "4. Clique em 'Generate token'"
echo "5. Copie o token"
echo ""
read -sp "Cole seu GitHub token: " GITHUB_TOKEN
echo ""

if [ -z "$GITHUB_TOKEN" ]; then
    echo -e "${RED}❌ GitHub token é obrigatório${NC}"
    exit 1
fi

# Hugging Face Token
echo ""
echo -e "${YELLOW}⚠️  Você precisa criar um token no Hugging Face:${NC}"
echo "1. Acesse: https://huggingface.co/settings/tokens"
echo "2. Clique em 'New token'"
echo "3. Selecione 'read'"
echo "4. Clique em 'Generate token'"
echo "5. Copie o token"
echo ""
read -sp "Cole seu Hugging Face token: " HF_TOKEN
echo ""

if [ -z "$HF_TOKEN" ]; then
    echo -e "${RED}❌ Hugging Face token é obrigatório${NC}"
    exit 1
fi

# Vercel Token
echo ""
echo -e "${YELLOW}⚠️  Você precisa criar um token na Vercel:${NC}"
echo "1. Acesse: https://vercel.com/account/tokens"
echo "2. Clique em 'Create''"
echo "3. Dê um nome (ex: Rosa Palmeirao)"
echo "4. Clique em 'Create'"
echo "5. Copie o token"
echo ""
read -sp "Cole seu Vercel token: " VERCEL_TOKEN
echo ""

if [ -z "$VERCEL_TOKEN" ]; then
    echo -e "${RED}❌ Vercel token é obrigatório${NC}"
    exit 1
fi

echo ""

# ============================================
# PASSO 3: Instalar Dependências
# ============================================
echo -e "${BLUE}📦 Instalando dependências...${NC}"
npm install
echo -e "${GREEN}✅ Dependências instaladas${NC}"
echo ""

# ============================================
# PASSO 4: Criar arquivo .env.local
# ============================================
echo -e "${BLUE}⚙️  Criando arquivo .env.local...${NC}"

cat > .env.local << EOF
# Database
DATABASE_URL="postgresql://user:password@host/database"

# Hugging Face
HUGGING_FACE_API_KEY="$HF_TOKEN"

# App Config
VITE_APP_TITLE="Rosa Palmeirão"
NODE_ENV="production"
EOF

echo -e "${GREEN}✅ Arquivo .env.local criado${NC}"
echo ""

# ============================================
# PASSO 5: Fazer Upload para GitHub
# ============================================
echo -e "${BLUE}🐙 Fazendo upload para GitHub...${NC}"

# Verificar se já é um repositório git
if [ ! -d ".git" ]; then
    git init
    git add .
    git commit -m "Initial commit - Rosa Palmeirao"
fi

# Adicionar remote
REPO_URL="https://$GITHUB_USERNAME:$GITHUB_TOKEN@github.com/$GITHUB_USERNAME/rosa-palmeirao.git"
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"

# Fazer push
git branch -M main
git push -u origin main

echo -e "${GREEN}✅ Código enviado para GitHub${NC}"
echo ""

# ============================================
# PASSO 6: Fazer Deploy na Vercel
# ============================================
echo -e "${BLUE}🚀 Fazendo deploy na Vercel...${NC}"

# Instalar Vercel CLI
npm install -g vercel

# Fazer deploy
VERCEL_OUTPUT=$(vercel --token "$VERCEL_TOKEN" --prod --yes 2>&1)
VERCEL_URL=$(echo "$VERCEL_OUTPUT" | grep -oP 'https://[^ ]+' | head -1)

if [ -z "$VERCEL_URL" ]; then
    echo -e "${RED}❌ Erro ao fazer deploy na Vercel${NC}"
    echo "$VERCEL_OUTPUT"
    exit 1
fi

echo -e "${GREEN}✅ Deploy realizado com sucesso!${NC}"
echo ""

# ============================================
# PASSO 7: Configurar Variáveis de Ambiente na Vercel
# ============================================
echo -e "${BLUE}🔐 Configurando variáveis de ambiente...${NC}"

vercel env add DATABASE_URL --token "$VERCEL_TOKEN" --prod << EOF
postgresql://user:password@host/database
EOF

vercel env add HUGGING_FACE_API_KEY --token "$VERCEL_TOKEN" --prod << EOF
$HF_TOKEN
EOF

echo -e "${GREEN}✅ Variáveis configuradas${NC}"
echo ""

# ============================================
# PASSO 8: Criar Banco de Dados
# ============================================
echo -e "${BLUE}🗄️  Criando banco de dados...${NC}"

# Usar Vercel Postgres
echo -e "${YELLOW}⚠️  Você precisa criar um banco de dados na Vercel:${NC}"
echo "1. Acesse: https://vercel.com/dashboard/stores"
echo "2. Clique em 'Create Database'"
echo "3. Selecione 'Postgres'"
echo "4. Escolha a região"
echo "5. Clique em 'Create'"
echo "6. Copie a connection string"
echo "7. Cole aqui:"
echo ""
read -p "Cole a connection string do banco de dados: " DB_URL

if [ -z "$DB_URL" ]; then
    echo -e "${RED}❌ Connection string é obrigatória${NC}"
    exit 1
fi

# Atualizar variável de ambiente
vercel env add DATABASE_URL --token "$VERCEL_TOKEN" --prod << EOF
$DB_URL
EOF

echo -e "${GREEN}✅ Banco de dados configurado${NC}"
echo ""

# ============================================
# RESULTADO FINAL
# ============================================
echo ""
echo "============================================"
echo -e "${GREEN}🎉 SUCESSO! Seu app está online!${NC}"
echo "============================================"
echo ""
echo -e "🌐 ${BLUE}Seu link: ${YELLOW}$VERCEL_URL${NC}"
echo ""
echo "Próximos passos:"
echo "1. Acesse: $VERCEL_URL"
echo "2. Clique em 'Cadastre-se'"
echo "3. Use seu email: $EMAIL"
echo "4. Crie uma senha"
echo "5. Comece a usar!"
echo ""
echo "Documentação:"
echo "- Guia completo: SETUP_DEPLOYMENT.md"
echo "- Guia rápido: COMECE_AQUI.md"
echo ""
echo "============================================"
echo ""

# Salvar informações em arquivo
cat > deployment-info.txt << EOF
Rosa Palmeirão - Informações de Deployment
==========================================

Data: $(date)
Email: $EMAIL
GitHub: https://github.com/$GITHUB_USERNAME/rosa-palmeirao
Vercel: $VERCEL_URL

Banco de Dados: Configurado
Hugging Face: Configurado
Assinatura: Ativa

Status: ✅ PRONTO PARA USAR
EOF

echo -e "${GREEN}✅ Informações salvas em: deployment-info.txt${NC}"

