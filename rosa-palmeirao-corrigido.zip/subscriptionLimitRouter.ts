import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./_core/db";
import { users, userTrialLimits } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Tipos de funcionalidades com limite de teste
export const TRIAL_FEATURES = {
  generateImage: { name: "Gerar Imagem", limit: 1 },
  generateDance: { name: "Gerar Vídeo de Dança", limit: 1 },
  generateChat: { name: "Gerar Chat", limit: 3 },
  generateCreative: { name: "Gerar Criativo", limit: 1 },
} as const;

export type TrialFeature = keyof typeof TRIAL_FEATURES;

/**
 * Verificar se usuário tem assinatura ativa
 */
async function hasActiveSubscription(userId: string, db: any): Promise<boolean> {
  try {
    const user = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (user.length === 0) return false;

    const userData = user[0];
    
    // Verificar se tem assinatura ativa
    if (!userData.subscriptionStatus || userData.subscriptionStatus !== "active") {
      return false;
    }

    // Verificar se assinatura expirou
    if (userData.subscriptionExpiresAt && new Date(userData.subscriptionExpiresAt) < new Date()) {
      return false;
    }

    return true;
  } catch (error) {
    console.error("Erro ao verificar assinatura:", error);
    return false;
  }
}

/**
 * Obter uso de teste do usuário
 */
async function getTrialUsage(userId: string, feature: TrialFeature, db: any): Promise<number> {
  try {
    const result = await db
      .select()
      .from(userTrialLimits)
      .where(eq(userTrialLimits.userId, userId))
      .limit(1);

    if (result.length === 0) {
      // Criar registro inicial
      await db.insert(userTrialLimits).values({
        userId,
        generateImageCount: 0,
        generateDanceCount: 0,
        generateChatCount: 0,
        generateCreativeCount: 0,
      });
      return 0;
    }

    const fieldName = `${feature}Count` as keyof typeof result[0];
    return result[0][fieldName] || 0;
  } catch (error) {
    console.error("Erro ao obter uso de teste:", error);
    return 0;
  }
}

/**
 * Incrementar uso de teste
 */
async function incrementTrialUsage(userId: string, feature: TrialFeature, db: any): Promise<void> {
  try {
    const fieldName = `${feature}Count`;
    
    const result = await db
      .select()
      .from(userTrialLimits)
      .where(eq(userTrialLimits.userId, userId))
      .limit(1);

    if (result.length === 0) {
      // Criar registro
      const data: any = {
        userId,
        generateImageCount: 0,
        generateDanceCount: 0,
        generateChatCount: 0,
        generateCreativeCount: 0,
      };
      data[fieldName] = 1;
      await db.insert(userTrialLimits).values(data);
    } else {
      // Atualizar registro
      const updateData: any = {};
      updateData[fieldName] = (result[0][fieldName as keyof typeof result[0]] || 0) + 1;
      
      await db
        .update(userTrialLimits)
        .set(updateData)
        .where(eq(userTrialLimits.userId, userId));
    }
  } catch (error) {
    console.error("Erro ao incrementar uso de teste:", error);
  }
}

export const subscriptionLimitRouter = router({
  /**
   * Verificar se pode usar funcionalidade (com teste gratuito ou assinatura)
   */
  canUseFeature: publicProcedure
    .input(z.object({
      feature: z.enum(["generateImage", "generateDance", "generateChat", "generateCreative"]),
    }))
    .query(async ({ input, ctx }) => {
      try {
        if (!ctx.user) {
          return {
            allowed: false,
            reason: "Não autenticado",
            hasSubscription: false,
            trialUsed: 0,
            trialLimit: TRIAL_FEATURES[input.feature].limit,
            canDownload: false,
          };
        }

        const db = await getDb();
        if (!db) {
          return {
            allowed: false,
            reason: "Erro ao conectar ao banco de dados",
            hasSubscription: false,
            trialUsed: 0,
            trialLimit: TRIAL_FEATURES[input.feature].limit,
            canDownload: false,
          };
        }

        // Verificar se tem assinatura
        const hasSubscription = await hasActiveSubscription(ctx.user.id, db);

        if (hasSubscription) {
          return {
            allowed: true,
            reason: "Assinatura ativa",
            hasSubscription: true,
            trialUsed: 0,
            trialLimit: TRIAL_FEATURES[input.feature].limit,
            canDownload: true,
          };
        }

        // Verificar uso de teste
        const trialUsed = await getTrialUsage(ctx.user.id, input.feature, db);
        const trialLimit = TRIAL_FEATURES[input.feature].limit;
        const allowed = trialUsed < trialLimit;

        return {
          allowed,
          reason: allowed ? "Teste disponível" : "Limite de teste atingido",
          hasSubscription: false,
          trialUsed,
          trialLimit,
          canDownload: false,
        };
      } catch (error) {
        return {
          allowed: false,
          reason: error instanceof Error ? error.message : "Erro desconhecido",
          hasSubscription: false,
          trialUsed: 0,
          trialLimit: TRIAL_FEATURES[input.feature].limit,
          canDownload: false,
        };
      }
    }),

  /**
   * Registrar uso de funcionalidade
   */
  recordFeatureUsage: publicProcedure
    .input(z.object({
      feature: z.enum(["generateImage", "generateDance", "generateChat", "generateCreative"]),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        if (!ctx.user) throw new Error("Não autenticado");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Verificar se tem assinatura
        const hasSubscription = await hasActiveSubscription(ctx.user.id, db);

        if (!hasSubscription) {
          // Incrementar uso de teste
          await incrementTrialUsage(ctx.user.id, input.feature, db);
        }

        return { success: true };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Erro ao registrar uso");
      }
    }),

  /**
   * Obter status de assinatura do usuário
   */
  getSubscriptionStatus: publicProcedure.query(async ({ ctx }) => {
    try {
      if (!ctx.user) {
        return {
          hasSubscription: false,
          status: "none",
          expiresAt: null,
          trialLimits: {
            generateImage: { used: 0, limit: TRIAL_FEATURES.generateImage.limit },
            generateDance: { used: 0, limit: TRIAL_FEATURES.generateDance.limit },
            generateChat: { used: 0, limit: TRIAL_FEATURES.generateChat.limit },
            generateCreative: { used: 0, limit: TRIAL_FEATURES.generateCreative.limit },
          },
        };
      }

      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Obter dados do usuário
      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (user.length === 0) {
        return {
          hasSubscription: false,
          status: "none",
          expiresAt: null,
          trialLimits: {
            generateImage: { used: 0, limit: TRIAL_FEATURES.generateImage.limit },
            generateDance: { used: 0, limit: TRIAL_FEATURES.generateDance.limit },
            generateChat: { used: 0, limit: TRIAL_FEATURES.generateChat.limit },
            generateCreative: { used: 0, limit: TRIAL_FEATURES.generateCreative.limit },
          },
        };
      }

      const userData = user[0];
      const hasSubscription = await hasActiveSubscription(ctx.user.id, db);

      // Obter limites de teste
      const trialData = await db
        .select()
        .from(userTrialLimits)
        .where(eq(userTrialLimits.userId, ctx.user.id))
        .limit(1);

      const limits = trialData.length > 0 ? trialData[0] : null;

      return {
        hasSubscription,
        status: userData.subscriptionStatus || "none",
        expiresAt: userData.subscriptionExpiresAt,
        trialLimits: {
          generateImage: {
            used: limits?.generateImageCount || 0,
            limit: TRIAL_FEATURES.generateImage.limit,
          },
          generateDance: {
            used: limits?.generateDanceCount || 0,
            limit: TRIAL_FEATURES.generateDance.limit,
          },
          generateChat: {
            used: limits?.generateChatCount || 0,
            limit: TRIAL_FEATURES.generateChat.limit,
          },
          generateCreative: {
            used: limits?.generateCreativeCount || 0,
            limit: TRIAL_FEATURES.generateCreative.limit,
          },
        },
      };
    } catch (error) {
      console.error("Erro ao obter status de assinatura:", error);
      return {
        hasSubscription: false,
        status: "error",
        expiresAt: null,
        trialLimits: {
          generateImage: { used: 0, limit: TRIAL_FEATURES.generateImage.limit },
          generateDance: { used: 0, limit: TRIAL_FEATURES.generateDance.limit },
          generateChat: { used: 0, limit: TRIAL_FEATURES.generateChat.limit },
          generateCreative: { used: 0, limit: TRIAL_FEATURES.generateCreative.limit },
        },
      };
    }
  }),

  /**
   * Obter informações de upgrade
   */
  getUpgradeInfo: publicProcedure.query(async ({ ctx }) => {
    return {
      plans: [
        {
          name: "Básico",
          price: "R$ 29,90",
          period: "mês",
          features: [
            "✅ Gerar imagens ilimitadas",
            "✅ Gerar vídeos ilimitados",
            "✅ Chat ilimitado",
            "✅ Criativos ilimitados",
            "✅ Download de conteúdo",
            "✅ Sem anúncios",
          ],
        },
        {
          name: "Premium",
          price: "R$ 79,90",
          period: "mês",
          features: [
            "✅ Tudo do Básico",
            "✅ Prioridade no suporte",
            "✅ Acesso a novos recursos",
            "✅ Exportação em HD",
            "✅ API access",
          ],
        },
      ],
      message: "Faça upgrade para desbloquear todas as funcionalidades!",
    };
  }),
});

